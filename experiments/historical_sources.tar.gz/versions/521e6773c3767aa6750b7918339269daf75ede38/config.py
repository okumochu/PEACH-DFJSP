"""
Configuration for graph-based RL experiments (HGT).

Split into two parts:
- TrainingConfig: everything needed to train a model
- ExperimentConfig: everything needed to run inference / benchmarks

Helper functions (create_hgt_config, create_inference_config, etc.)
live in src/utils/config_util.py.
"""


# ------------------------------------------------------------------ #
# Training Configuration
# ------------------------------------------------------------------ #

class TrainingConfig:
    """Everything needed to train a model."""

    def __init__(self):
        # Problem parameters (base values; curriculum dynamic-event params
        # are merged in by create_hgt_config).
        self.problem_params = {
            'job_num': 20,
            'machine_num': 10,
            # Due Date Tightness factor k ~ U[ddt_min, ddt_max]
            'due_date_tightness': [0.5, 1.5],
            # Urgency Degree (Weight) ~ U_int[weight_min, weight_max]
            'urgency_weight': [1, 5],
            # Operations per job ~ U_int[ops_min, ops_max]
            'operation_per_job': [1, 10],
            # Compatible machines per operation ~ U_int[mch_min, mch_max]
            'machine_per_operation': [1, 10],
            # Processing Time ~ U[pt_min, pt_max]
            'process_time': [1, 50],
        }

        # Objective weights (saved in checkpoint for critic pruning)
        self.objective_weights = {
            'makespan_weight': 0.5,
            'twt_weight': 0.5,
        }

        # Training hyperparameters
        self.training = {
            'lr': 3e-5,
            'gamma': 1.0,
            'k_epochs': 4,
            'eps_clip': 0.2,
            'vloss_coef': 0.5,
            'ploss_coef': 1.0,
            'gae_lambda': 0.98,
            'minibatch_size': 256,
            'max_grad_norm': 1.0,
            'entropy_coef': 0.0,
            'hidden_dim': 128,
            'num_hgt_layers': 4,
            'num_heads': 1,
            'dropout': 0.1,
        }

        # Validation
        self.validation = {
            'update_per_validate': 200,
            'seed': 42,
            'validation_set_size': 30,
        }

        # Resumable checkpointing.
        self.training['checkpoint_every'] = 400

        self.curriculum_learning = {
            'enabled': True,
            'initial_due_date_tightness': [1.0, 2.5],
            'ddt_stage_ratio': 0.60,
            'ddt_min_substage_ratio': 0.5,
            'events_enabled': True,
            'dynamic_event_params': {
                'num_new_job_arrival_waves': [2, 2],
                'num_machine_breakdown_waves': [2, 2],
                'num_priority_change_waves': [0, 0],
                # machine breakdowns — match capacity_shock
                'mtbf': [90, 120],
                'machines_per_breakdown': [3, 5],
                'repair_duration': [120, 120],
                # new-job arrivals — match priority_shock
                'new_job_lambda_inv': [90, 120],
                'new_jobs_per_arrival': [3, 4],
                'new_job_weight': [5, 5],
                'new_job_due_date_tightness': [0.3, 0.8],
            },
        }

        self.static_design = {
            'use_dynamic_event_features': False,
            'use_anchored_segments': False,
            'ddt_stage_ratio': 1.0,
            'events_enabled': False,
        }

        self.dispatch_rules = {
            'menu': ['FIFO', 'SPT', 'EDD', 'WSPT',
                     'ATC_1.0', 'ATC_2.0', 'ATC_3.0', 'ATC_4.0', 'MS',
                     'COVERT_1.0', 'COVERT_2.0', 'COVERT_3.0', 'COVERT_4.0',
                     'CR', 'MOD', 'AVPRO', 'NPT'],
            'k_grid': [1.0, 2.0, 3.0, 4.0],
            'num_runs': 30,
        }

        # Common training settings
        self.device = 'cuda'
        self.seed = 42
        self.wandb_project = 'DFJSP_multi _criteria'
        self.num_envs = 20
        self.max_updates = 2000
        self.reset_env_episode = 1

    @property
    def common_params(self):
        """DataGenerator compatibility."""
        n_j = self.problem_params['job_num']
        n_m = self.problem_params['machine_num']
        return {
            'device': self.device,
            'wandb_project': self.wandb_project,
            'model_name': f'{n_j}X{n_m}_static',
        }


# ------------------------------------------------------------------ #
# Experiment Configuration
# ------------------------------------------------------------------ #

class ExperimentConfig:
    """Everything needed to run inference / benchmarks."""

    def __init__(self):
        # Problem params shared by inference / benchmark scripts. Static only:
        # dynamic-event defaults are centralized in ``_EVENT_RANGE_DEFAULTS``
        # (src/utils/config_util.py) and applied via normalize_generation_ranges,
        # so they are not duplicated here. Scripts that need events set them
        # explicitly (e.g. exp_large_scale_dispatching via ``large_scale_params``).
        self.problem_params = {
            'job_num': 20,
            'machine_num': 10,
            'due_date_tightness': [0.5, 1.5],
            'urgency_weight': [1, 5],
            'operation_per_job': [1, 10],
            'machine_per_operation': [1, 10],
            'process_time': [1, 50],
        }

        # Large-scale dispatching-rule baseline experiment.
        # Expanded paper-aligned menu: original fixed rules plus tunable ATC
        # and COVERT broken out by k-value. Includes priority changes because
        # this is a multi-criteria objective with TWT.
        self.large_scale_params = {
            'job_num': 100,
            'machine_num': 20,

            # Two complementary disruption archetypes, swept together by
            # exp_large_scale_dispatching.py (no single default scenario). Each
            # is self-contained: it lists its own wave counts (which event
            # types fire) and the intensity of those events.
            #   priority_shock - demand-side: rush arrivals + reprioritization,
            #                    no capacity loss (stresses responsiveness/TWT).
            #   capacity_shock - supply-side: simultaneous multi-machine
            #                    breakdowns, no new demand (stresses rerouting).
            'scenarios': {
                'priority_shock': {
                    'num_new_job_arrival_waves': [2, 2],
                    'num_machine_breakdown_waves': [0, 0],
                    'num_priority_change_waves': [2, 2],
                    # Arrival times are cumulative exponential gaps (wave i mean
                    # ≈ i × mean_gap). The 100x20 greedy horizon is ≈740, so the
                    # 2 arrival waves land within the first ~60% (mean ~14% &
                    # 28%). exp_large_scale_dispatching couples each priority
                    # change to an arrival wave — they fire at the SAME time (one
                    # demand event = rush arrival + reprioritization) — so
                    # priority_change_interval is unused here (it stays only as
                    # the generator default). See project_event_timing_horizon.
                    'new_job_lambda_inv': [90, 120],    # 2 arrivals → ~mean 14% & 28% of H
                    'priority_change_interval': [120, 150],  # unused: priority coupled to arrivals in-exp
                    'new_jobs_per_arrival': [3, 4],
                    'new_job_weight': [5, 5],
                    'new_job_due_date_tightness': [0.3, 0.8],
                    'priority_jobs_per_change': [8, 12],
                    'priority_new_weight': [5, 5],
                },
                'capacity_shock': {
                    'num_new_job_arrival_waves': [0, 0],
                    'num_machine_breakdown_waves': [2, 2],
                    'num_priority_change_waves': [0, 0],
                    # 2 breakdown waves (cumulative exponential gaps, mean=mtbf).
                    # 100x20 greedy horizon ≈700; mtbf≈105 places the waves at
                    # ~mean 15% & 30% so both typically land within the first
                    # ~60% of the schedule (soft target via the parameter, not a
                    # hard cap). The old mtbf=475 fired waves 2–3 past makespan.
                    'mtbf': [90, 120],    # 2 breakdowns → ~mean 15% & 30% of H≈700
                    'machines_per_breakdown': [3, 5],
                    'repair_duration': [120, 120],
                },
            },
            'rules': ['FIFO', 'SPT', 'EDD', 'WSPT',
                      'ATC_1.0', 'ATC_2.0', 'ATC_3.0', 'ATC_4.0', 'MS',
                      'COVERT_1.0', 'COVERT_2.0', 'COVERT_3.0', 'COVERT_4.0',
                      'CR', 'MOD', 'AVPRO', 'NPT'],
        }


        # Solver parameters
        self.solver = {
            # MILP single-phase wall-clock budget (seconds). At expiry, return
            # whatever incumbent was found, or 'Timeout No Feasible' if none.
            'milp_time_limit': 28800,
            # Gurobi MIPFocus. 1 = focus on finding feasible solutions quickly,
            # 2 = prove optimality, 3 = improve best objective bound.
            'milp_mip_focus': 1,
            'milp_verbose': 0,
            # GA baseline — Defersha & Rooyani (2020) "two-stage GA" paper.
            # Defaults are the **median** of Table 6's 40-set parameter sweep,
            # since the paper reports results over the full sweep and no single
            # "best" set is defensible. Stagnation (no-improvement for
            # ga_stagnation_generations consecutive generations) is the primary
            # stopping criterion within each stage; ga_time_limit is a
            # safeguard (halved per stage inside FJSP_GA → 4h per stage at 28800).
            'ga_population_size': 2000,        # median of {1000, 2000, 3000}
            'ga_generations': 1_000_000,       # effectively unlimited; stagnation triggers first
            'ga_time_limit': 28800,            # 8h total per solve safeguard
            'ga_stagnation_generations': 200,  # break stage when best_obj unchanged for N consecutive gens
            'ga_tournament_factor': 0.010,     # median of {0.005, 0.010, 0.015}
            'ga_crossover_rate_sco': 0.80,     # p1, median of {0.65, 0.80, 0.95}
            'ga_crossover_rate_jco': 0.80,     # p2, median of {0.65, 0.80, 0.95}
            'ga_crossover_rate_aco': 0.80,     # p3, median of {0.65, 0.80, 0.95}
            'ga_mutation_rate_osm': 0.10,      # p4, median of {0.05, 0.10, 0.15}
            'ga_mutation_rate_aam': 0.10,      # p5, median of {0.05, 0.10, 0.15}
        }

        # Experiment settings
        self.model_path = (
            'model/ablation_baseline/20260512_11/'
            'best_hgt_20X10_static.pth'
        )
        self.single_obj_model_path = (
            'model/exp_so_SD2_20x10/20260528_08/'
            'best_hgt_so_SD2_20X10_static.pth'
        )
        self.single_obj_generator = 'SD2'
        # HGT_dispatch (state-conditioned switching dispatching rule) baseline
        # checkpoint. Used by exp_large_scale_dispatching.py to add
        # rl_dispatch as a method column alongside rl. Set to None on the CLI
        # (or here) to skip the dispatch baseline.
        self.dispatch_model_path = (
            'model/exp_hgt_dispatch/20260517_21/'
            'best_hgt_dispatch_20X10_dynamic.pth'
        )
        self.num_runs = 5
        self.device = 'cuda'
        self.seed = 42

    @property
    def common_params(self):
        """DataGenerator compatibility."""
        return {'device': self.device}


# ------------------------------------------------------------------ #
# Single-Objective Training Configuration (makespan only, no TWT)
# ------------------------------------------------------------------ #

class TrainingConfigSingleObj:
    """Makespan-only training config (DANIEL SD1/SD2 replication).

    Standalone — does NOT inherit ``TrainingConfig``. The single-obj
    pipeline (``src/HGT_single_objective/``) is already makespan-only,
    has no curriculum, no dynamic events, no TWT weights; so carrying
    those knobs here just to disable them would be noise.

    Per-run knobs (``n_j``, ``n_m``, ``generator_type``) come from CLI via
    ``create_hgt_single_obj_config``; the SD1/SD2 distribution constants
    live in ``DataGeneratorSingleObj``, not here.
    """

    def __init__(self):
        # PPO / HGT hyperparameters
        self.training = {
            'lr': 3e-5,
            'gamma': 1.0,
            'k_epochs': 4,
            'eps_clip': 0.2,
            'vloss_coef': 0.5,
            'ploss_coef': 1.0,
            'gae_lambda': 0.98,
            'minibatch_size': 256,
            'max_grad_norm': 1.0,
            'entropy_coef': 0.0,
            'hidden_dim': 128,
            'num_hgt_layers': 4,
            'num_heads': 1,
            'dropout': 0.1,
        }

        self.validation = {
            'update_per_validate': 100,
            'seed': 42,
            'validation_set_size': 30,
        }

        # Schedule + misc
        self.device = 'cuda'
        self.seed = 42
        self.wandb_project = 'DFJSP_single_obj'
        self.num_envs = 20
        self.max_updates = 4000
        self.reset_env_episode = 1


# ------------------------------------------------------------------ #
# Global singletons
# ------------------------------------------------------------------ #
training_config = TrainingConfig()
training_config_single_obj = TrainingConfigSingleObj()
experiment_config = ExperimentConfig()

# Inference scripts read the dispatch-rule menu, so expose the (training-side)
# definition on the experiment config too — single source of truth lives in
# TrainingConfig.
experiment_config.dispatch_rules = training_config.dispatch_rules

# Backward-compat alias
config = experiment_config
