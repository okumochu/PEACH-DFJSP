import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions.categorical import Categorical
import numpy as np
import time
import subprocess
import os
import random
import sys
from copy import deepcopy
from typing import Dict, Any, Optional, List, Tuple
from tqdm import tqdm
import wandb

from .hgt_network import HGT
from .hgt_env import FJSPEnvHGT, HGTEnvState
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

from src.data_generator import create_data_generator
from src.utils.checkpoint_util import checkpoint_safe_metadata
from src.utils.config_util import resolve_dp_lb_diff_enabled
from src.utils.reproducibility import seed_context, set_global_seed
from src.utils.rl_utils import sample_action, eval_actions, greedy_select_action
from src.utils.event_utils import merge_and_sort_events
from src.utils.segment_util import (
    pop_next_event_set, freeze_segment_ops, absorb_breakdowns)
from src.utils.gantt_util import extract_schedule_from_env




class Memory:
    """Memory for PPO training following DANIEL structure"""
    
    def __init__(self, gamma, gae_lambda):
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        
        # Input variables for HGT
        self.candidate_mask_seq = []  # [N, tensor[sz_b, J, M]]
        self.candidate_seq = []  # [N, tensor[sz_b, J]]
        self.candidate_pt_indices_seq = []  # [N, tensor[sz_b, J, M]] PT node indices
        self.graph_seq = []  # [N, HeteroData] - Additional for HGT
        
        # Other variables
        self.action_seq = []  # action index with shape [N, tensor[sz_b]]
        self.reward_seq = []  # reward value with shape [N, tensor[sz_b]]
        self.val_seq = []  # state value with shape [N, tensor[sz_b]]
        self.log_probs = []  # log(p_{\theta_old}(a_t|s_t)) with shape [N, tensor[sz_b]]
        # Per-step event-boundary flags ([N, tensor[sz_b]], 1.0 where a dynamic
        # event fired). Used only by the legacy single-trajectory (static /
        # inline) GAE path; the anchored-segment path does not need it.
        self.event_boundary_seq = []

        # Anchored-segment rollout bookkeeping (empty for the legacy path).
        # ``active_mask_seq`` is a per-step [sz_b] bool: True where the env took
        # a real action this step (False once it finished its segment, since
        # segments seeded from different-size partial schedules end at different
        # steps). ``segment_lengths`` records each segment's step count so GAE
        # runs per-segment — each env's last active step in a segment is a TRUE
        # terminal, so value targets never bootstrap across a dynamic event.
        self.active_mask_seq = []
        self.segment_lengths = []
        # Flat [B*N] bool of valid (active) samples, set by get_gae_advantages();
        # PPO.update() filters minibatches to these. None -> all valid.
        self.active_flat = None

    def clear_memory(self):
        self.clear_state()
        del self.action_seq[:]
        del self.reward_seq[:]
        del self.val_seq[:]
        del self.log_probs[:]
        del self.event_boundary_seq[:]
        del self.active_mask_seq[:]
        del self.segment_lengths[:]
        self.active_flat = None
    
    def clear_state(self):
        del self.candidate_mask_seq[:]
        del self.candidate_seq[:]
        del self.candidate_pt_indices_seq[:]
        del self.graph_seq[:]
    
    def push(self, state: HGTEnvState):
        """Push a state into the memory"""
        self.candidate_mask_seq.append(state.candidate_mask_tensor)
        self.candidate_seq.append(state.candidate_tensor)
        self.candidate_pt_indices_seq.append(state.candidate_pt_indices)
        self.graph_seq.append(state.graph_tensor)
    
    @staticmethod
    def _pad_seq_to_jmax(seq, fill):
        """Right-pad each [B, J, ...] tensor in ``seq`` along the job axis to the
        max J across the sequence. Anchored segments collected after a job
        arrival have a larger J than earlier segments; padding lets them stack.
        The HGT actor masks padded slots (candidate_mask=1, pt_idx=-1) and
        zero-pads job embeddings, and the flattened action index ``job*M+mch``
        is invariant to J, so padding does not affect the policy. No-op (returns
        ``seq``) when all entries already share J (the rectangular path)."""
        if not seq:
            return seq
        j_max = max(t.shape[1] for t in seq)
        if all(t.shape[1] == j_max for t in seq):
            return seq
        out = []
        for t in seq:
            if t.shape[1] == j_max:
                out.append(t)
                continue
            pad_shape = (t.shape[0], j_max - t.shape[1]) + tuple(t.shape[2:])
            pad = torch.full(pad_shape, fill, dtype=t.dtype, device=t.device)
            out.append(torch.cat([t, pad], dim=1))
        return out

    def transpose_data(self):
        """Transpose the first and second dimension of collected variables"""
        # Pad ragged-J segments (arrivals grow the job count) so they stack.
        cmask_seq = self._pad_seq_to_jmax(self.candidate_mask_seq, fill=1.0)
        cand_seq = self._pad_seq_to_jmax(self.candidate_seq, fill=0)
        cpt_seq = self._pad_seq_to_jmax(self.candidate_pt_indices_seq, fill=-1)
        t_candidateMask_seq = torch.stack(cmask_seq, dim=0).transpose(0, 1).flatten(0, 1)
        t_candidate_seq = torch.stack(cand_seq, dim=0).transpose(0, 1).flatten(0, 1)
        t_candidate_pt_indices_seq = torch.stack(cpt_seq, dim=0).transpose(0, 1).flatten(0, 1)
        t_action_seq = torch.stack(self.action_seq, dim=0).transpose(0, 1).flatten(0, 1)
        t_reward_seq = torch.stack(self.reward_seq, dim=0).transpose(0, 1).flatten(0, 1)
        self.t_old_val_seq = torch.stack(self.val_seq, dim=0).transpose(0, 1)
        t_val_seq = self.t_old_val_seq.flatten(0, 1)
        t_logprobs_seq = torch.stack(self.log_probs, dim=0).transpose(0, 1).flatten(0, 1)
        
        # Flatten graph sequence to align EXACTLY with tensor flattening order (env-major, then time)
        # Original tensors are stacked as [T, B, ...] -> transpose to [B, T, ...] -> flatten(0,1)
        # So the order is: for each env b in 0..B-1, for each t in 0..T-1
        t_graph_seq = []
        if len(self.graph_seq) > 0:
            num_envs = len(self.graph_seq[0])  # Number of environments (B)
            num_time = len(self.graph_seq)      # Number of time steps (T)
            for env_idx in range(num_envs):
                for time_step in range(num_time):
                    t_graph_seq.append(self.graph_seq[time_step][env_idx])
        
        return (t_candidateMask_seq,
                t_candidate_seq, t_candidate_pt_indices_seq, t_graph_seq,
                t_action_seq, t_reward_seq, t_val_seq, t_logprobs_seq)
    
    def get_gae_advantages(self):
        """Compute GAE advantages and value targets.

        Dispatches on whether this rollout was collected as anchored segments
        (``segment_lengths`` populated) or as a single trajectory (legacy
        static / inline path). Sets ``self.active_flat`` so PPO.update() can
        drop masked (inactive) samples.
        """
        if self.segment_lengths:
            return self._segmented_gae()
        self.active_flat = None
        return self._single_trajectory_gae()

    def _single_trajectory_gae(self):
        """Legacy single-trajectory GAE (used by the static / inline path).

        Event-boundary truncation: at steps where a dynamic event fired,
        ``event_boundary_seq`` is 1.0, zeroing the GAE carry term. For the
        static path the mask is all-zero, so this is plain GAE.
        """
        reward_arr = torch.stack(self.reward_seq, dim=0)
        t_old_val_seq = self.t_old_val_seq  # reuse from transpose_data()
        values = t_old_val_seq.transpose(0, 1)
        len_trajectory, len_envs = reward_arr.shape

        if len(self.event_boundary_seq) == len_trajectory:
            boundary = torch.stack(self.event_boundary_seq, dim=0).to(
                device=values.device, dtype=reward_arr.dtype)
        else:
            boundary = torch.zeros(
                len_trajectory, len_envs, device=values.device, dtype=reward_arr.dtype)

        advantage = torch.zeros(len_envs, device=values.device)
        advantage_seq = []
        for i in reversed(range(len_trajectory)):
            if i == len_trajectory - 1:
                delta_t = reward_arr[i] - values[i].squeeze()
            else:
                delta_t = reward_arr[i] + self.gamma * values[i + 1].squeeze() - values[i].squeeze()
            advantage = delta_t + self.gamma * self.gae_lambda * (1.0 - boundary[i]) * advantage
            advantage_seq.append(advantage)
        advantage_seq.reverse()

        t_advantage_seq = torch.stack(advantage_seq, dim=0).transpose(0, 1).to(torch.float32)
        v_target_seq = (t_advantage_seq + t_old_val_seq).flatten(0, 1)

        # Normalization
        t_advantage_seq = (t_advantage_seq - t_advantage_seq.mean(dim=1, keepdim=True)) / \
                          (t_advantage_seq.std(dim=1, keepdim=True) + 1e-8)

        return t_advantage_seq.flatten(0, 1), v_target_seq

    def _segmented_gae(self):
        """Anchored-segment GAE.

        The rollout is a concatenation (along time) of per-segment blocks given
        by ``segment_lengths``. Each segment is a complete static episode, so
        GAE runs INDEPENDENTLY per block: an env's last active step in a block
        is a true terminal (delta = r - V, no bootstrap), and no advantage ever
        crosses an event boundary -> the critic only estimates the return
        conditioned on already-realized events. ``active_mask_seq`` marks which
        envs were still scheduling at each step (envs seeded from larger fixed
        prefixes finish earlier); inactive steps contribute nothing.

        Flattening order matches ``transpose_data`` (env-major: flat index
        b*N + n), so ``active_flat`` aligns with the flattened tensors.
        """
        device = self.t_old_val_seq.device
        reward_arr = torch.stack(self.reward_seq, dim=0).to(device)         # [N, B]
        values = self.t_old_val_seq.transpose(0, 1)                         # [N, B]
        active = torch.stack(self.active_mask_seq, dim=0).to(
            device=device, dtype=torch.bool)                               # [N, B]
        N, B = reward_arr.shape

        advantages = torch.zeros(N, B, device=device)
        seg_start = 0
        for seg_len in self.segment_lengths:
            seg_end = seg_start + seg_len            # block [seg_start, seg_end)
            adv = torch.zeros(B, device=device)
            for i in reversed(range(seg_start, seg_end)):
                act_i = active[i]                    # [B] bool
                if i + 1 < seg_end:
                    next_act = active[i + 1]
                    v_next = torch.where(
                        next_act, values[i + 1], torch.zeros_like(values[i + 1]))
                else:
                    next_act = torch.zeros(B, dtype=torch.bool, device=device)
                    v_next = torch.zeros(B, device=device)
                delta = reward_arr[i] + self.gamma * v_next - values[i]
                adv = delta + self.gamma * self.gae_lambda * next_act.float() * adv
                adv = torch.where(act_i, adv, torch.zeros_like(adv))
                advantages[i] = adv
            seg_start = seg_end

        t_advantage_seq = advantages.transpose(0, 1).to(torch.float32)      # [B, N]
        v_target_seq = (t_advantage_seq + self.t_old_val_seq).flatten(0, 1)  # [B*N]

        # Per-env advantage normalization over ACTIVE entries only (inactive
        # zeros would otherwise bias the mean/std).
        active_bn = active.transpose(0, 1).float()                          # [B, N]
        cnt = active_bn.sum(dim=1, keepdim=True).clamp(min=1.0)
        mean = (t_advantage_seq * active_bn).sum(dim=1, keepdim=True) / cnt
        var = (((t_advantage_seq - mean) ** 2) * active_bn).sum(
            dim=1, keepdim=True) / cnt
        std = var.sqrt()
        t_advantage_seq = (t_advantage_seq - mean) / (std + 1e-8)
        t_advantage_seq = t_advantage_seq * active_bn                       # zero inactive

        self.active_flat = active_bn.flatten(0, 1).bool()                   # [B*N]
        return t_advantage_seq.flatten(0, 1), v_target_seq


class PPO:
    """PPO algorithm following DANIEL structure.

    Subclasses can override the class attribute ``policy_cls`` to swap the
    policy network (e.g. ``HGTDispatch``). ``entropy_coef`` (read from
    ``config``, defaults to 0) adds ``-entropy_coef * H(pi)`` to the loss —
    used by HGT_dispatch's small action space; HGT defaults to 0 so behavior
    is unchanged.
    """

    policy_cls = HGT

    def __init__(self, config):
        self.lr = config.lr
        self.gamma = config.gamma
        self.gae_lambda = config.gae_lambda
        self.eps_clip = config.eps_clip
        self.k_epochs = config.k_epochs

        self.ploss_coef = config.ploss_coef
        self.vloss_coef = config.vloss_coef
        self.minibatch_size = config.minibatch_size
        self.max_grad_norm = config.max_grad_norm
        self.entropy_coef = float(getattr(config, 'entropy_coef', 0.0))

        self.policy = self.policy_cls(config)
        self.policy_old = deepcopy(self.policy)

        self.optimizer = torch.optim.Adam(self.policy.parameters(), lr=self.lr)
        self.V_loss_2 = nn.MSELoss()
        self.device = torch.device(config.device)
        self.wandb_enabled = getattr(config, 'wandb_enabled', True)
    
    def update(self, memory, update_step=0, raw_rewards=None, raw_makespan=None, raw_twt=None,
               makespan_weight=1.0, twt_weight=1.0):
        """Update policy using PPO"""
        t_data = memory.transpose_data()
        t_advantage_seq, v_target_seq = memory.get_gae_advantages()

        # Restrict the update to valid (active) samples. For the anchored-segment
        # rollout, inactive steps (envs that already finished their segment) are
        # masked out entirely so they never enter a minibatch / the loss. For
        # the legacy path active_flat is None -> all samples are valid.
        active_flat = getattr(memory, 'active_flat', None)
        if active_flat is None:
            valid_idx = torch.arange(len(t_data[-1]))
        else:
            valid_idx = torch.nonzero(active_flat, as_tuple=True)[0].cpu()
        full_batch_size = len(valid_idx)
        num_batch = np.ceil(full_batch_size / self.minibatch_size)
        
        loss_epochs = 0
        v_loss_epochs = 0
        p_loss_epochs = 0
        
        # Accumulators for logging metrics across all minibatches
        total_v_loss = 0
        total_p_loss = 0
        total_total_loss = 0
        total_grad_norm = 0
        num_minibatch_updates = 0
        
        for epoch in range(self.k_epochs):
            perm = valid_idx[torch.randperm(full_batch_size)]
            for i in range(int(num_batch)):
                start_idx = i * self.minibatch_size
                end_idx = min((i + 1) * self.minibatch_size, full_batch_size)
                indices = perm[start_idx:end_idx]

                candidate_mask = t_data[0][indices]
                candidate = t_data[1][indices]
                candidate_pt_indices = t_data[2][indices]
                graph_seq = [t_data[3][idx] for idx in indices.tolist()]
                
                pis, vals = self.policy(
                    candidate=candidate,
                    candidate_mask=candidate_mask,
                    candidate_pt_indices=candidate_pt_indices,
                    graph=graph_seq
                )
                
                action_batch = t_data[4][indices]
                logprobs, entropy = eval_actions(pis, action_batch)
                ratios = torch.exp(logprobs - t_data[7][indices].detach())

                advantages = t_advantage_seq[indices]
                surr1 = ratios * advantages
                surr2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages

                v_loss = self.V_loss_2(vals.squeeze(-1), v_target_seq[indices])
                p_loss = -torch.min(surr1, surr2)
                loss = (self.vloss_coef * v_loss
                        + self.ploss_coef * p_loss
                        - self.entropy_coef * entropy)
                
                loss_mean = loss.mean()
                v_loss_mean = v_loss.mean()
                p_loss_mean = p_loss.mean()

                self.optimizer.zero_grad()
                loss_epochs += loss_mean.detach()
                v_loss_epochs += v_loss_mean.detach()
                p_loss_epochs += p_loss_mean.detach()
                loss_mean.backward()

                # Clip gradients and get pre-clip norm in one pass
                grad_norm = torch.nn.utils.clip_grad_norm_(
                    self.policy.parameters(), self.max_grad_norm).item()

                self.optimizer.step()

                # Accumulate metrics for averaged logging
                total_v_loss += v_loss_mean.item()
                total_p_loss += p_loss_mean.item()
                total_total_loss += loss_mean.item()
                total_grad_norm += grad_norm
                num_minibatch_updates += 1
            
        
        # Build metrics dict for caller to log (single wandb.log per update)
        update_metrics = {}
        if num_minibatch_updates > 0:
            update_metrics = {
                'value_loss': total_v_loss / num_minibatch_updates,
                'policy_loss': total_p_loss / num_minibatch_updates,
                'total_loss': total_total_loss / num_minibatch_updates,
                'gradient_norm': total_grad_norm / num_minibatch_updates,
                'raw_reward': np.mean(raw_rewards) if raw_rewards is not None else 0,
                'raw_makespan': np.mean(raw_makespan) if raw_makespan is not None else 0,
                'raw_twt': np.mean(raw_twt) if raw_twt is not None else 0,
                'raw_objective': (makespan_weight * np.mean(raw_makespan) if raw_makespan is not None else 0) +
                                 (twt_weight * np.mean(raw_twt) if raw_twt is not None else 0),
            }

        # Hard copy of policy to policy_old after each update
        for p_old, p in zip(self.policy_old.parameters(), self.policy.parameters()):
            p_old.data.copy_(p.data)
        for b_old, b in zip(self.policy_old.buffers(), self.policy.buffers()):
            b_old.data.copy_(b.data)
        
        return (loss_epochs.item() / self.k_epochs,
                v_loss_epochs.item() / self.k_epochs,
                p_loss_epochs.item() / self.k_epochs,
                update_metrics)


class HGTTrainer:
    """HGT Trainer following DANIEL structure"""
    
    def __init__(self, config):
        self.n_j = config.n_j
        self.n_m = config.n_m
        self.config = config
        self.max_updates = config.max_updates
        self.reset_env_episode = config.reset_env_episode  # Number of episodes to use same batch
        self.num_envs = config.num_envs
        self.seed = int(getattr(config, 'seed', 42))
        self.reproducibility = set_global_seed(self.seed)
        config.reproducibility = self.reproducibility
        
        # Data generator. With CL on the pacer overrides ``num_*`` event
        # counts per update; with CL off they stay at the configured target.
        self.data_generator = create_data_generator(config)

        # Curriculum learning
        cl_params = getattr(config, 'curriculum_learning', {})
        self.use_curriculum = cl_params.get('enabled', False)
        if self.use_curriculum:
            self.data_generator.init_curriculum(cl_params, config.max_updates)

        self.use_lowerbound_differencing = resolve_dp_lb_diff_enabled(config)

        # Anchored-segment rollout (dynamic design): collect each rollout as a
        # chain of linked static episodes split at dynamic-event boundaries, so
        # value targets never bootstrap across an event. Defaults to the dynamic
        # design flag (on when use_dynamic_event_features is True), off for the
        # old/static design. See _collect_segmented_rollout.
        self.use_anchored_segments = bool(getattr(
            config, 'use_anchored_segments',
            getattr(config, 'use_dynamic_event_features', True)))

        # Use pre-defined result directory from config if provided, otherwise use a default
        self.result_dir = getattr(config, 'result_dir', f'./result')
        
        self.data_name = f'{self.n_j}x{self.n_m}'
        # Get model_name directly from config (should be in common_params)
        self.model_name = getattr(config, "model_name", self.data_name)
        
        # Objective weights (saved in checkpoint for critic pruning)
        self.objective_weights = getattr(config, 'objective_weights',
                                         {'makespan_weight': 0.5, 'twt_weight': 0.5})

        # Initialize environment
        self.env = self._create_environment()
        self.env_class = type(self.env)

        # Set feature dimensions from environment (important for dynamic mode with extended features)
        config.op_feature_dim = self.env.op_fea_dim
        config.job_feature_dim = self.env.job_fea_dim
        config.machine_feature_dim = self.env.mch_fea_dim
        config.pt_feature_dim = self.env.pt_fea_dim

        # Initialize PPO (after feature dims are set)
        self.ppo = PPO(config)
        self.memory = Memory(gamma=config.gamma, gae_lambda=config.gae_lambda)

        # Validation parameters. A single fixed dynamic-validation fixture is
        # sampled from target parameters and reused throughout the run.
        self.update_per_validate = getattr(config, 'update_per_validate', 100)
        self.validation_seed = getattr(
            config, 'validation_seed', getattr(config, 'seed', 42))
        self.validation_set_size = getattr(config, 'validation_set_size', 30)
        self.validation_data = self._generate_validation_set()
        self.best_val_objective = float('inf')

        # Resumable checkpointing. ``checkpoint_every`` updates -> a full
        # training-state snapshot (resume_state.pth) is overwritten so an
        # OOM-/SIGTERM-killed run can continue instead of restarting. The
        # curriculum pacer is a pure function of the update index, so resume
        # only needs (weights, optimizer, RNG, update index, best-val, wandb id).
        self.checkpoint_every = int(getattr(config, 'checkpoint_every', 100))
        self.resume_path = getattr(config, 'resume_path', None)
        self.start_update = 0
        self._resume_wandb_id = None
        self._wandb_run_id = None

        # Load full state BEFORE wandb.init so we can rejoin the same W&B run.
        if self.resume_path and os.path.exists(self.resume_path):
            self._load_resume_checkpoint(self.resume_path)

        # Initialize wandb
        self.wandb_project = getattr(config, 'wandb_project', 'exp_hgt')
        self.wandb_enabled = getattr(config, 'wandb_enabled', True)

        if self.wandb_enabled:
            run_name = getattr(config, 'wandb_run_name', None)
            if not run_name or not isinstance(run_name, str):
                run_name = f"HGT_{self.data_name}_{self.model_name}"
            init_kwargs = dict(
                project=self.wandb_project,
                name=run_name,
                config=vars(config),
            )
            # Rejoin the prior run on resume so the learning curve is continuous.
            if self._resume_wandb_id:
                init_kwargs['id'] = self._resume_wandb_id
                init_kwargs['resume'] = 'allow'
            wandb.init(**init_kwargs)
            self._wandb_run_id = wandb.run.id if wandb.run is not None else None
    
    
    def _create_environment(self):
        env = FJSPEnvHGT(self.n_j, self.n_m, device=self.config.device,
                         use_lowerbound_differencing=self.use_lowerbound_differencing,
                         use_pt_nodes=getattr(self.config, 'use_pt_nodes', True),
                         use_dynamic_event_features=getattr(
                             self.config, 'use_dynamic_event_features', True))
        env.makespan_weight = self.objective_weights['makespan_weight']
        env.twt_weight = self.objective_weights['twt_weight']
        return env
    
    def sample_training_instances(self):
        """
            Sample training instances using data generator.
            
        :return: Dict with 'static' data (and 'dynamic_events', 'dynamic_jobs' for dynamic mode)
        """
        # Both static and dynamic modes use sample_env which returns a dict
        return self.data_generator.sample_env(self.num_envs)

    # ------------------------------------------------------------------
    # Anchored-segment rollout (dynamic design)
    # ------------------------------------------------------------------

    def _collect_segmented_rollout(self, data):
        """Collect one rollout as a chain of linked static episodes.

        ``E_0`` = the original problem solved with NO events, to termination
        (the anchor whose return supplies low-variance value targets for the
        pre-event states). At each event boundary we freeze the ops that started
        before the event into a per-env fixed prefix, absorb the event, and seed
        the next segment from that partial schedule via
        ``set_initial_data_with_fixed_schedule`` -- the exact path inference
        uses (``src/utils/segment_util.py`` is the shared freeze/absorb rule).

        Every segment is a complete static episode, so GAE never bootstraps
        across an event: the critic only estimates the return conditioned on
        already-realized events. Transitions for all segments are appended to
        ``self.memory`` with per-step active masks and per-segment lengths.

        Returns ``(final_env, ep_rewards)`` where ``final_env`` holds the full
        realized schedule (fixed prefix + last segment) for makespan/TWT logging
        and ``ep_rewards`` is the per-env total reward (for monitoring).
        """
        # Lazy import to avoid an import cycle (inference_env imports hgt_env).
        from src.HGT.inference_env import (
            _copy_static, _wrap_as_static_data,
            _append_arriving_job, _apply_priority_change)

        B = self.num_envs
        n_m = self.n_m
        # Event schedule is shared across the B envs (same boundary times); each
        # env's frozen prefix differs because its schedule differs.
        event_queue = merge_and_sort_events(data.get('dynamic_events', {}))
        current_static = _copy_static(data['static'])
        dyn_jobs = data.get('dynamic_jobs') or {}
        ddt_min = float(dyn_jobs.get('ddt_min', 0.5))
        ddt_max = float(dyn_jobs.get('ddt_max', 1.5))
        n_j0 = len(current_static['job_length'][0])

        fixed_ops = [[] for _ in range(B)]                 # per-env carry-forward
        mch_unavailable_until = np.zeros((B, n_m), dtype=np.float32)
        job_release_times = [[0.0] * n_j0 for _ in range(B)]
        current_time = 0.0

        self.memory.clear_memory()
        last_env = self.env
        seg_idx = 0
        n_arr = n_bd = n_pc = 0          # applied-event counts (for logging)
        while True:
            wrapped = _wrap_as_static_data(current_static)
            if seg_idx == 0:
                state = self.env.set_initial_data_static(wrapped)
            else:
                state = self.env.set_initial_data_with_fixed_schedule(
                    wrapped,
                    fixed_ops=fixed_ops,
                    mch_unavailable_until=mch_unavailable_until.copy(),
                    job_release_times=np.asarray(job_release_times, dtype=np.float32),
                    current_time=current_time,
                )

            # Roll this segment (no events inside) to termination.
            self._roll_segment_into_memory(state)
            last_env = self.env

            if not event_queue:
                break

            # Extract each env's full segment schedule, then freeze + absorb the
            # next event-set into the seed for the following segment.
            seg_scheds = [extract_schedule_from_env(self.env, e)['schedule']
                          for e in range(B)]
            event_set, t = pop_next_event_set(event_queue)
            for e in range(B):
                fixed_ops[e], _interrupted = freeze_segment_ops(
                    seg_scheds[e], fixed_ops[e], event_set, t, env_idx=e)
                absorb_breakdowns(fixed_ops[e], mch_unavailable_until[e], event_set)

            # Arrivals/priority change the shared static problem (same for all
            # envs); release times grow per arrival.
            for evt in event_set:
                if evt['type'] == 'job_arrival':
                    _append_arriving_job(current_static, data, evt, ddt_min, ddt_max)
                    for e in range(B):
                        job_release_times[e].append(float(evt['time']))
                    n_arr += 1
                elif evt['type'] == 'machine_breakdown':
                    n_bd += 1
                elif evt['type'] == 'priority_change':
                    _apply_priority_change(current_static, evt)
                    n_pc += 1
            current_time = t
            seg_idx += 1

        # Expose applied-event counts in the same shape the legacy inline path
        # used (per-env arrays) so the wandb logging block is unchanged.
        self.env.fired_event_counts = {
            'job_arrival': np.full(B, n_arr, dtype=np.int64),
            'machine_breakdown': np.full(B, n_bd, dtype=np.int64),
            'priority_change': np.full(B, n_pc, dtype=np.int64),
        }

        if self.memory.reward_seq:
            ep_rewards = torch.stack(self.memory.reward_seq, dim=0).sum(
                dim=0).detach().cpu().numpy()
        else:
            ep_rewards = np.zeros(B, dtype=np.float32)
        return last_env, ep_rewards

    def _roll_segment_into_memory(self, state):
        """Roll one static segment to termination, appending transitions.

        Only active (not-yet-done) envs are forwarded/sampled each step; the
        env's step() skips done envs so their terminal state is preserved. A
        per-step active mask and the segment's step count are recorded for the
        per-segment GAE.
        """
        B = self.num_envs
        dev = self.ppo.device
        seg_len = 0
        while True:
            active = ~self.env.done()                       # [B] bool
            if not active.any():
                break
            self.memory.push(state)                         # full-B state
            a_idx = np.where(active)[0]
            a_idx_t = torch.as_tensor(a_idx, device=dev, dtype=torch.long)

            graph_active = [state.graph_tensor[e] for e in a_idx]
            with torch.no_grad():
                pi_envs, vals_envs = self.ppo.policy_old(
                    candidate=state.candidate_tensor[a_idx_t],
                    candidate_mask=state.candidate_mask_tensor[a_idx_t],
                    candidate_pt_indices=state.candidate_pt_indices[a_idx_t],
                    graph=graph_active,
                )
            act_sub, logp_sub = sample_action(pi_envs)

            # Scatter active-env outputs into full-B tensors (inactive -> 0).
            action_full = np.zeros(B, dtype=np.int64)
            action_full[a_idx] = act_sub.detach().cpu().numpy()
            val_full = torch.zeros(B, device=dev)
            val_full[a_idx_t] = vals_envs.squeeze(-1).to(dev)
            logp_full = torch.zeros(B, device=dev)
            logp_full[a_idx_t] = logp_sub.to(dev)

            state, reward, _done = self.env.step(action_full)

            active_t = torch.as_tensor(active, device=dev)
            reward_t = torch.from_numpy(
                np.asarray(reward, dtype=np.float32)).to(dev) * active_t.float()

            self.memory.action_seq.append(
                torch.as_tensor(action_full, device=dev, dtype=torch.long))
            self.memory.log_probs.append(logp_full)
            self.memory.val_seq.append(val_full)
            self.memory.reward_seq.append(reward_t)
            self.memory.active_mask_seq.append(active_t)
            seg_len += 1

        self.memory.segment_lengths.append(seg_len)

    def _generate_validation_set(self):
        """Sample one fixed target-distribution dynamic validation batch."""
        validation_config = deepcopy(self.config)
        problem_params = dict(getattr(self.config, 'problem_params', {}) or {})
        if not problem_params:
            problem_params = dict(getattr(self.config, 'static_params', {}) or {})
        dynamic_event_params = dict(
            getattr(self.config, 'dynamic_event_params', {}) or {})
        validation_config.problem_params = {
            **problem_params,
            **dynamic_event_params,
        }

        with seed_context(self.validation_seed):
            validation_generator = create_data_generator(validation_config)
            return validation_generator.sample_env(self.validation_set_size)

    def _greedy_rollout(self, val_data):
        """Greedy rollout on ``val_data`` (a batched static_data dict).

        Events fire mid-rollout when ``val_data['dynamic_events']`` is
        non-empty — same path as training (``_post_step_hook`` simple-push).
        Returns ``(makespan, twt, objective)`` averaged over the batch.
        """
        val_env = FJSPEnvHGT(self.n_j, self.n_m, device=self.config.device,
                             use_lowerbound_differencing=self.use_lowerbound_differencing,
                             use_pt_nodes=getattr(self.config, 'use_pt_nodes', True),
                             use_dynamic_event_features=getattr(
                                 self.config, 'use_dynamic_event_features', True))
        val_env.makespan_weight = self.objective_weights['makespan_weight']
        val_env.twt_weight = self.objective_weights['twt_weight']

        state = val_env.set_initial_data_static(val_data)

        self.ppo.policy.eval()
        try:
            while True:
                with torch.no_grad():
                    pi, _ = self.ppo.policy(
                        candidate=state.candidate_tensor,
                        candidate_mask=state.candidate_mask_tensor,
                        candidate_pt_indices=state.candidate_pt_indices,
                        graph=state.graph_tensor,
                    )
                action = greedy_select_action(pi)
                state, reward, done = val_env.step(action.cpu().numpy())
                if done.all():
                    break
        finally:
            self.ppo.policy.train()

        makespan = float(np.mean(val_env.current_makespan))
        twt = float(np.mean(getattr(
            val_env, 'current_twt', np.zeros(self.validation_set_size))))
        mw = getattr(val_env, 'makespan_weight', 1.0)
        tw = getattr(val_env, 'twt_weight', 1.0)
        return makespan, twt, mw * makespan + tw * twt

    def _run_validation(self):
        """Run fixed dynamic validation and return ``(makespan, twt, objective)``."""
        return self._greedy_rollout(self.validation_data)

    def train(self):
        """Train the model following DANIEL structure"""
        self.train_st = time.time()

        # Persist an initial resume point immediately, before the first update.
        # earlyoom on this shared box SIGTERMs the largest python process the
        # moment host memory gets tight, which can happen within minutes -- well
        # before the first periodic snapshot (every ``checkpoint_every``
        # updates). Without this initial write, such an early kill leaves no
        # resume_state.pth, so the relaunch (a) restarts training from scratch
        # and (b) cannot rejoin the W&B run (its id is stored in the snapshot),
        # spawning a brand-new run. Writing it here lets both survive a kill at
        # any point. Skipped on resume (an up-to-date snapshot already exists).
        if self.start_update == 0:
            self._save_resume_checkpoint(next_update=0)

        for i_update in tqdm(range(self.start_update, self.max_updates),
                             initial=self.start_update, total=self.max_updates,
                             file=sys.stdout, desc="progress", colour='blue'):
            ep_st = time.time()
            
            # Curriculum learning: always resample (DDT changes each step). The
            # first iteration after a resume (i_update == start_update) always
            # resamples so neither rollout path touches a stale/never-seeded env
            # (the legacy path's env.reset() needs a prior set_initial_data).
            should_resample = (self.use_curriculum
                               or i_update == self.start_update
                               or i_update % self.reset_env_episode == 0)
            if should_resample and self.use_curriculum:
                ddt_min, ddt_max = self.data_generator.update_curriculum(i_update)

            if self.use_anchored_segments:
                # Anchored-segment rollout: a chain of linked static episodes
                # (see _collect_segmented_rollout). The driver re-seeds self.env
                # per segment and fills self.memory; after the last segment
                # self.env holds the full realized schedule.
                if should_resample or not hasattr(self, '_segment_data'):
                    self._segment_data = self.sample_training_instances()
                _last_env, ep_rewards = self._collect_segmented_rollout(
                    self._segment_data)
            else:
                if should_resample:
                    data = self.sample_training_instances()
                    state = self.env.set_initial_data_static(data)
                else:
                    state = self.env.reset()

                ep_rewards = -self.env.init_quality.copy()

                while True:
                    # Store state
                    self.memory.push(state)

                    with torch.no_grad():
                        pi_envs, vals_envs = self.ppo.policy_old(
                            candidate=state.candidate_tensor,  # [sz_b, J]
                            candidate_mask=state.candidate_mask_tensor,  # [sz_b, J, M]
                            candidate_pt_indices=state.candidate_pt_indices,  # [sz_b, J, M]
                            graph=state.graph_tensor  # List of HeteroData for batched processing
                        )

                    # Sample action
                    action_envs, action_logprob_envs = sample_action(pi_envs)

                    # State transition
                    state, reward, done = self.env.step(actions=action_envs.cpu().numpy())
                    ep_rewards += reward
                    reward = torch.from_numpy(reward).to(self.ppo.device)

                    # Collect transition
                    self.memory.reward_seq.append(reward)
                    self.memory.action_seq.append(action_envs)
                    self.memory.log_probs.append(action_logprob_envs)
                    self.memory.val_seq.append(vals_envs.squeeze(1))
                    # Event-boundary flag for GAE truncation (zeros when no event
                    # fired this step, or when the env exposes no event hook).
                    ev_fired = getattr(self.env, 'last_events_fired', None)
                    if ev_fired is None:
                        ev_fired = np.zeros(self.env.number_of_envs, dtype=np.float32)
                    self.memory.event_boundary_seq.append(
                        torch.as_tensor(np.asarray(ev_fired, dtype=np.float32),
                                        device=self.ppo.device))

                    if done.all():
                        break

            # PPO update
            loss, v_loss, p_loss, update_metrics = self.ppo.update(
                self.memory, update_step=i_update,
                raw_rewards=ep_rewards, raw_makespan=self.env.current_makespan,
                raw_twt=getattr(self.env, 'current_twt', None),
                makespan_weight=getattr(self.env, 'makespan_weight', 1.0),
                twt_weight=getattr(self.env, 'twt_weight', 1.0))

            self.memory.clear_memory()

            # Collect all metrics for this update step to emit a single wandb log
            metrics_to_log = dict(update_metrics)

            # Always log DDT — flat line (CL off) and ramp (CL on) overlay cleanly in wandb.
            if self.wandb_enabled:
                gen_params = self.data_generator.get_params()
                fired_counts = getattr(self.env, 'fired_event_counts', {}) or {}
                zeros = np.zeros(self.num_envs, dtype=np.int64)
                metrics_to_log.update({
                    'curriculum/ddt_min': gen_params['due_date_tightness_min'],
                    'curriculum/ddt_max': gen_params['due_date_tightness_max'],
                    'curriculum/avg_new_job_arrivals': float(np.mean(
                        fired_counts.get('job_arrival', zeros))),
                    'curriculum/avg_machine_breakdowns': float(np.mean(
                        fired_counts.get('machine_breakdown', zeros))),
                    'curriculum/avg_priority_changes': float(np.mean(
                        fired_counts.get('priority_change', zeros))),
                })

            # Periodic validation on the fixed target dynamic batch. Always
            # validate on the final update so the fully-trained model can be
            # selected as best (otherwise update max_updates-1 is never scored).
            if (i_update % self.update_per_validate == 0
                    or i_update == self.max_updates - 1):
                val_ms, val_twt, val_obj = self._run_validation()
                tqdm.write(
                    f'[Validation @ {i_update}] '
                    f'obj={val_obj:.2f} (ms={val_ms:.2f}, twt={val_twt:.2f})')

                # Canonical best model is selected by fixed dynamic validation.
                if val_obj < self.best_val_objective:
                    self.best_val_objective = val_obj
                    self.save_model(model_name=f"best_{self.model_name}")
                    tqdm.write(f'  -> New best model (obj: {val_obj:.2f})')

                if self.wandb_enabled:
                    metrics_to_log.update({
                        'val/makespan': val_ms,
                        'val/twt': val_twt,
                        'val/objective': val_obj,
                        'val/best_objective': self.best_val_objective,
                    })

            # Log all combined metrics at once
            if self.wandb_enabled and metrics_to_log:
                metrics_to_log['update_step'] = i_update
                wandb.log(metrics_to_log)

            mean_rewards_all_env = np.mean(ep_rewards)
            mean_makespan_all_env = np.mean(self.env.current_makespan)
            mean_twt_all_env = np.mean(getattr(self.env, 'current_twt', np.zeros(self.num_envs)))
            # Compute combined objective with environment weights
            makespan_w = getattr(self.env, 'makespan_weight', 1.0)
            twt_w = getattr(self.env, 'twt_weight', 1.0)
            mean_objective_all_env = makespan_w * mean_makespan_all_env + twt_w * mean_twt_all_env

            ep_et = time.time()

            # Periodic full-state snapshot for resume (overwrites in place).
            # next_update = i_update+1 so a relaunch restarts at the first
            # not-yet-completed update.
            if (i_update + 1) % self.checkpoint_every == 0:
                self._save_resume_checkpoint(next_update=i_update + 1)


        self.train_et = time.time()
        
        # Log training wall time
        effective_train_time = self.train_et - self.train_st
        if self.wandb_enabled:
            wandb.log({'train/training_wall_clock_s': effective_train_time})

        # Save model once at the end of training
        self.save_model()

        # Final resume snapshot, flagged complete so a relaunch skips this run.
        self._save_resume_checkpoint(next_update=self.max_updates, completed=True)

        # Finish wandb logging
        if self.wandb_enabled:
            wandb.finish()
    
    def save_model(self, model_name=None):
        """Save the model with all network hyperparameters for reproducibility."""
        if model_name is None:
            model_name = self.model_name
        # Extract all HGT network hyperparameters explicitly
        hgt_hyperparams = {
            'n_j': self.config.n_j,
            'n_m': self.config.n_m,
            'op_feature_dim': getattr(self.config, 'op_feature_dim', 9),
            'job_feature_dim': getattr(self.config, 'job_feature_dim', 7),
            'machine_feature_dim': getattr(self.config, 'machine_feature_dim', 6),
            'pt_feature_dim': getattr(self.config, 'pt_feature_dim', 2),
            'hidden_dim': getattr(self.config, 'hidden_dim', 32),
            'num_hgt_layers': getattr(self.config, 'num_hgt_layers', 4),
            'num_heads': getattr(self.config, 'num_heads', 2),
            'dropout': getattr(self.config, 'dropout', 0.1),
            'lr': getattr(self.config, 'lr', 3e-5),
            'gamma': getattr(self.config, 'gamma', 1.0),
            'gae_lambda': getattr(self.config, 'gae_lambda', 0.98),
            'eps_clip': getattr(self.config, 'eps_clip', 0.2),
            'k_epochs': getattr(self.config, 'k_epochs', 4),
            'max_grad_norm': getattr(self.config, 'max_grad_norm', 1.0),
            'vloss_coef': getattr(self.config, 'vloss_coef', 0.5),
            'ploss_coef': getattr(self.config, 'ploss_coef', 1.0),
            'objective_weights': self.objective_weights,
            'seed': self.seed,
            'reproducibility': dict(getattr(
                self.config, 'reproducibility', self.reproducibility)),
            'use_pt_nodes': bool(getattr(self.config, 'use_pt_nodes', True)),
            'use_dynamic_event_features': bool(getattr(
                self.config, 'use_dynamic_event_features', True)),
            'use_anchored_segments': bool(self.use_anchored_segments),
            'dp_lb_diff': {
                'enabled': self.use_lowerbound_differencing,
            },
            'actor_channels': self.ppo.policy.actor.channel_list,
            'critic_channels': self.ppo.policy.critic.channel_list,
        }

        save_obj = {
            'state_dict': self.ppo.policy.state_dict(),
            'hgt_hyperparams': checkpoint_safe_metadata(hgt_hyperparams),
            'config': checkpoint_safe_metadata(self.config),
        }
        torch.save(save_obj, f"{self.result_dir}/{model_name}.pth")

    # ------------------------------------------------------------------
    # Resumable full-state checkpoint (distinct from the best/final model)
    # ------------------------------------------------------------------

    def resume_checkpoint_path(self):
        """Canonical resume-snapshot path inside this run's result dir."""
        return os.path.join(self.result_dir, 'resume_state.pth')

    def _save_resume_checkpoint(self, next_update, completed=False):
        """Atomically write a full training-state snapshot for resume.

        Stores everything needed to continue training byte-for-byte-ish: the
        policy / policy_old weights, the Adam optimizer state, the global RNG
        states, the next update index, the best validation objective so far, and
        the W&B run id (to rejoin the same run). The curriculum pacer is a pure
        function of the update index, so it is reconstructed for free. Written to
        a temp file then os.replace()'d so a kill mid-write can't corrupt it.
        """
        cuda_rng = (torch.cuda.get_rng_state_all()
                    if torch.cuda.is_available() else None)
        state = {
            'next_update': int(next_update),
            'max_updates': int(self.max_updates),
            'completed': bool(completed),
            'best_val_objective': float(self.best_val_objective),
            'model_name': self.model_name,
            'seed': self.seed,
            'policy_state_dict': self.ppo.policy.state_dict(),
            'policy_old_state_dict': self.ppo.policy_old.state_dict(),
            'optimizer_state_dict': self.ppo.optimizer.state_dict(),
            'wandb_run_id': self._wandb_run_id,
            'rng': {
                'python': random.getstate(),
                'numpy': np.random.get_state(),
                'torch': torch.random.get_rng_state(),
                'cuda': cuda_rng,
            },
        }
        path = self.resume_checkpoint_path()
        tmp_path = path + '.tmp'
        torch.save(state, tmp_path)
        os.replace(tmp_path, path)

    def _load_resume_checkpoint(self, path):
        """Restore training state saved by :meth:`_save_resume_checkpoint`.

        Loads onto the training device (so model + optimizer state land on the
        right device); RNG state tensors are forced back to CPU because
        ``set_rng_state`` requires CPU ByteTensors. Sets ``self.start_update``,
        ``self.best_val_objective`` and ``self._resume_wandb_id`` for the caller.
        """
        # weights_only=False: our own trusted snapshot carries NumPy/Python RNG
        # state (not plain tensors), which the PyTorch>=2.6 weights_only loader
        # rejects. Safe here because we wrote this file ourselves.
        ckpt = torch.load(
            path, map_location=self.ppo.device, weights_only=False)

        if ckpt.get('completed'):
            print(f"[resume] {path} is already complete "
                  f"(update {ckpt.get('next_update')}/{ckpt.get('max_updates')}); "
                  "nothing left to train.")

        self.ppo.policy.load_state_dict(ckpt['policy_state_dict'])
        if 'policy_old_state_dict' in ckpt:
            self.ppo.policy_old.load_state_dict(ckpt['policy_old_state_dict'])
        else:
            self.ppo.policy_old.load_state_dict(ckpt['policy_state_dict'])
        self.ppo.optimizer.load_state_dict(ckpt['optimizer_state_dict'])

        self.best_val_objective = float(
            ckpt.get('best_val_objective', float('inf')))
        self.start_update = int(ckpt.get('next_update', 0))
        self._resume_wandb_id = ckpt.get('wandb_run_id', None)

        # Budget sanity: the curriculum pacer is keyed to self.max_updates (set
        # in __init__ from the freshly-built config), so a max_updates that
        # differs from the snapshot's silently shifts the remaining DDT ramp, and
        # one <= start_update makes the train loop a no-op. Extending the budget
        # is supported, so warn loudly rather than hard-fail.
        saved_max = ckpt.get('max_updates')
        if saved_max is not None and int(saved_max) != int(self.max_updates):
            print(f"[resume] WARNING: max_updates changed since the snapshot "
                  f"({saved_max} -> {self.max_updates}); the curriculum ramp is "
                  f"re-keyed to the new horizon. Intended only if you are "
                  f"deliberately changing the run length.")
        if self.start_update >= self.max_updates:
            print(f"[resume] WARNING: next update {self.start_update} >= "
                  f"max_updates {self.max_updates}; the training loop will be a "
                  f"NO-OP (nothing left to train under the current budget).")

        rng = ckpt.get('rng', {}) or {}
        try:
            if rng.get('python') is not None:
                random.setstate(rng['python'])
            if rng.get('numpy') is not None:
                np.random.set_state(rng['numpy'])
            if rng.get('torch') is not None:
                torch.random.set_rng_state(rng['torch'].cpu())
            if rng.get('cuda') is not None and torch.cuda.is_available():
                torch.cuda.set_rng_state_all([s.cpu() for s in rng['cuda']])
        except Exception as exc:  # RNG continuity is best-effort, not fatal.
            print(f"[resume] WARNING: could not fully restore RNG state: {exc}")

        print(f"[resume] Loaded {path}: continuing from update "
              f"{self.start_update}/{self.max_updates}, "
              f"best_val_objective={self.best_val_objective:.4f}")

    def load_model(self, model_path=None):
        """
        Load the trained model.
        
        The network is reconstructed using the hyperparameters saved with the model,
        ensuring compatibility even if the current config has different settings.
        """
        if model_path is None:
            model_path = f"{self.result_dir}/{self.model_name}.pth"
        
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model not found at {model_path}")
        
        loaded = torch.load(model_path, map_location=self.ppo.device if hasattr(self, 'ppo') else 'cuda')
        
        if isinstance(loaded, dict) and 'state_dict' in loaded:
            # If saved hyperparams exist, use them to reconstruct the network
            if 'hgt_hyperparams' in loaded:
                saved_hp = loaded['hgt_hyperparams']
                self.saved_hgt_hyperparams = saved_hp
                
                # Update config with saved hyperparameters for network reconstruction
                for param, value in saved_hp.items():
                    setattr(self.config, param, value)
                
                # Reinitialize PPO with the saved hyperparameters
                self.ppo = PPO(self.config)
            
            self.ppo.policy.load_state_dict(loaded['state_dict'])
            self.saved_config = loaded.get('config', None)

    # Removed CL generation helpers; data must be prepared before training
