"""Checkpoint metadata helpers.

Keep tensor payloads in ``state_dict`` untouched, but make metadata plain
Python data so PyTorch's default ``weights_only=True`` checkpoint loader can
read it.
"""

from argparse import Namespace
from pathlib import Path
from typing import Any

try:
    import numpy as np
except ImportError:  # pragma: no cover - numpy is a project dependency.
    np = None  # type: ignore


_SAFE_SCALAR_TYPES = (type(None), bool, int, float, str)


def checkpoint_safe_metadata(value: Any) -> Any:
    """Return a weights-only-loader-safe copy of checkpoint metadata."""
    if isinstance(value, Namespace):
        return checkpoint_safe_metadata(vars(value))
    if isinstance(value, dict):
        return {
            str(key): checkpoint_safe_metadata(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [checkpoint_safe_metadata(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    if value is None:
        return None
    if isinstance(value, bool):
        return bool(value)
    if isinstance(value, int):
        return int(value)
    if isinstance(value, float):
        return float(value)
    if isinstance(value, str):
        # ``torch.__version__`` is a TorchVersion subclass of str in newer
        # PyTorch builds; normalize it to a real built-in str.
        return str(value)

    if np is not None:
        if isinstance(value, np.bool_):
            return bool(value)
        if isinstance(value, np.integer):
            return int(value)
        if isinstance(value, np.floating):
            return float(value)
        if isinstance(value, np.ndarray):
            return checkpoint_safe_metadata(value.tolist())

    return str(value)


def is_checkpoint_safe_metadata(value: Any) -> bool:
    """Return True when metadata already consists only of safe built-ins."""
    if type(value) in _SAFE_SCALAR_TYPES:
        return True
    if type(value) is dict:
        return all(
            type(key) is str and is_checkpoint_safe_metadata(item)
            for key, item in value.items()
        )
    if type(value) is list:
        return all(is_checkpoint_safe_metadata(item) for item in value)
    return False
