"""
HGT_dispatch FJSP environment.

Subclasses :class:`src.HGT.hgt_env.FJSPEnvHGT` and overrides only ``step()``:
the external action becomes a rule-id per env (shape ``[E]`` int in
``[0, num_rules)``). Inside, the rule's vectorised scorer picks the best
``(job, machine)`` pair non-delay-style (just like
``src/benchmark/dispatching_rules.py:_select_action`` does for the standalone
runner) and the resulting flat action ``j * n_m + m`` is forwarded to the
parent's ``step`` unchanged.

Tunable rules (ATC, COVERT) live in the menu as parameterised entries
(``'ATC_2.0'``, ``'COVERT_1.5'``), so each menu slot carries its own k —
no single per-env hyperparameter needed.

State, observations, reward differencing, dynamic-event handling,
save/restore — all inherited verbatim. The only difference is the action
space.
"""

from __future__ import annotations

from typing import Optional, Sequence

import numpy as np

from src.HGT.hgt_env import FJSPEnvHGT
from src.HGT_dispatch.dispatching_rules_vec import (
    RULE_NAMES, select_actions_batched, parse_menu,
)


class FJSPEnvHGTDispatch(FJSPEnvHGT):
    """Same env, rule-id action space.

    Args:
        n_j, n_m, device, use_lowerbound_differencing: forwarded to
            ``FJSPEnvHGT``.
        rule_menu: ordered sequence of menu entries. Each entry is either a
            canonical rule name (``'FIFO'``, ``'SPT'``, ...) or a tunable
            rule with explicit k (``'ATC_2.0'``, ``'COVERT_1.5'``). The
            action ``a`` selects ``rule_menu[a]``. Defaults to all 11
            canonical rules (no tunable variants).
    """

    def __init__(self, n_j, n_m, device,
                 use_lowerbound_differencing: bool = True,
                 rule_menu: Optional[Sequence[str]] = None):
        super().__init__(
            n_j, n_m, device,
            use_lowerbound_differencing=use_lowerbound_differencing)
        menu = tuple(rule_menu) if rule_menu is not None else tuple(RULE_NAMES)
        # parse_menu validates each entry and rejects unknowns; raises on
        # malformed names so the failure surfaces at construction time, not
        # mid-rollout.
        self.rule_menu = menu
        self._parsed_menu = parse_menu(menu)

    @property
    def num_rules(self) -> int:
        return len(self.rule_menu)

    def step(self, actions):
        """Translate per-env rule indices to per-env flat (job*M + mch) actions.

        ``actions`` is an ``[E]`` int array of rule indices into
        ``self.rule_menu``. Kwarg name matches the parent's ``step`` so the
        trainer's ``self.env.step(actions=...)`` call works without a wrapper.
        """
        rule_ids = np.asarray(actions, dtype=np.int64).reshape(-1)
        if rule_ids.shape[0] != self.number_of_envs:
            raise ValueError(
                f"rule_action shape {rule_ids.shape} does not match "
                f"number_of_envs {self.number_of_envs}"
            )
        flat_action = select_actions_batched(self, rule_ids, self._parsed_menu)
        return super().step(flat_action)
