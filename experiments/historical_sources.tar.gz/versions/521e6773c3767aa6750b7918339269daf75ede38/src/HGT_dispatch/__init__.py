"""HGT_dispatch — single-agent RL with dispatching rules as actions.

Mirrors :mod:`src.HGT` exactly except for the action space: instead of
selecting a (job, machine) pair from a ``J*M`` grid, the policy selects one
rule from a small menu (default: 11 canonical rules) and the rule then
deterministically picks the (job, machine) pair to schedule. State,
reward differencing, and feature extractor are all reused from :mod:`src.HGT`.

See :mod:`src.HGT_dispatch.dispatching_rules_vec` for vectorised rule
scorers, :mod:`src.HGT_dispatch.hgt_dispatch_env` for the env subclass,
:mod:`src.HGT_dispatch.hgt_dispatch_network` for the policy network, and
:mod:`src.HGT_dispatch.hgt_dispatch_trainer` for the PPO trainer.
"""

from src.HGT_dispatch.hgt_dispatch_env import FJSPEnvHGTDispatch
from src.HGT_dispatch.hgt_dispatch_network import HGTDispatch
from src.HGT_dispatch.hgt_dispatch_trainer import HGTDispatchTrainer, PPODispatch
from src.HGT_dispatch.inference_env import (
    InferenceEnvDispatch, make_dispatch_greedy_solver_fn,
)
from src.HGT_dispatch.dispatching_rules_vec import (
    RULE_NAMES, score_per_rule, select_actions_batched,
    parse_rule_name, parse_menu,
)

__all__ = [
    "FJSPEnvHGTDispatch",
    "HGTDispatch",
    "HGTDispatchTrainer",
    "PPODispatch",
    "InferenceEnvDispatch",
    "make_dispatch_greedy_solver_fn",
    "RULE_NAMES",
    "score_per_rule",
    "select_actions_batched",
    "parse_rule_name",
    "parse_menu",
]
