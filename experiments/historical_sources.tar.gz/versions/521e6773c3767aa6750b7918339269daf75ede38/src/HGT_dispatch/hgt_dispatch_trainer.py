"""
HGT_dispatch trainer.

Specialises :mod:`src.HGT.hgt_trainer` with three hooks:

1. ``PPODispatch.policy_cls = HGTDispatch`` — the parent's PPO instantiates
   whatever ``policy_cls`` points at, so this is a one-line swap.
2. The parent ``PPO.update`` already applies ``-entropy_coef * H(pi)`` when
   ``config.entropy_coef > 0``; HGT_dispatch sets the default to 0.01 to keep
   the small (~11) action space from collapsing.
3. ``HGTDispatchTrainer._create_environment`` returns a
   :class:`FJSPEnvHGTDispatch` so the action-space difference is visible to
   the rollout loop.

Memory and the rest of the training/validation/save/load pipeline are
inherited unchanged.
"""

from __future__ import annotations

import os
from typing import Optional

import numpy as np
import torch

from src.HGT.hgt_trainer import HGTTrainer, PPO
from src.HGT_dispatch.hgt_dispatch_env import FJSPEnvHGTDispatch
from src.HGT_dispatch.hgt_dispatch_network import HGTDispatch
from src.HGT_dispatch.dispatching_rules_vec import RULE_NAMES
from src.utils.rl_utils import greedy_select_action


class PPODispatch(PPO):
    """PPO that builds a HGTDispatch policy.

    Inherits the entropy-bonus loss term from the parent (active because
    ``config.entropy_coef`` defaults to 0.01 in :func:`create_dispatch_config`).
    """

    policy_cls = HGTDispatch


class HGTDispatchTrainer(HGTTrainer):
    """Same training loop, rule-action env + rule-logits policy.

    Reads ``config.dispatch_rules`` (menu) and instantiates
    :class:`FJSPEnvHGTDispatch` with the matching menu. Tunable rules in
    the menu carry their k inline (e.g. ``'ATC_2.0'``), so the trainer
    holds no hyperparameter state of its own. The policy class is swapped
    via ``PPODispatch.policy_cls``, so we only need to override ``ppo_cls``
    indirectly through reassignment after super.
    """

    def __init__(self, config):
        dr_cfg = getattr(config, 'dispatch_rules', None) or {
            'menu': list(RULE_NAMES),
        }
        self.rule_menu = tuple(dr_cfg.get('menu', list(RULE_NAMES)))

        # Tell the network how many rules there are. Parent __init__ builds
        # PPO from `config`, so this must be set before super().__init__.
        config.num_rules = len(self.rule_menu)

        # Parent __init__ instantiates self.ppo = PPO(config). We replace it
        # with PPODispatch afterwards. The wasted HGT build is small relative
        # to a training run; cleaner alternatives (parameterising parent on
        # the PPO class) require touching the parent in ways that obscure
        # the HGT path's defaults.
        super().__init__(config)
        self.ppo = PPODispatch(config)
        # Resume would load weights/optimizer into the parent PPO inside
        # super().__init__, which the line above then discards -> a silently
        # wrong resume. Dispatch has no --resume entry point today; fail loudly
        # if one is ever wired in before this rebuild-after-load is handled.
        if getattr(self, 'resume_path', None):
            raise NotImplementedError(
                "Resume is not supported for HGTDispatchTrainer: self.ppo is "
                "rebuilt as PPODispatch after the parent loads the snapshot, "
                "discarding the restored policy/optimizer.")

    def _create_environment(self):
        env = FJSPEnvHGTDispatch(
            self.n_j, self.n_m, device=self.config.device,
            use_lowerbound_differencing=self.use_lowerbound_differencing,
            rule_menu=self.rule_menu,
        )
        env.makespan_weight = self.objective_weights['makespan_weight']
        env.twt_weight = self.objective_weights['twt_weight']
        return env

    def _greedy_rollout(self, val_data):
        """Greedy rule-action rollout on ``val_data`` (events fire mid-rollout
        when present in the data dict — same path as training)."""
        val_env = self._create_environment()
        state = val_env.set_initial_data_static(val_data)

        self.ppo.policy.eval()
        try:
            while True:
                with torch.no_grad():
                    pi, _ = self.ppo.policy(
                        candidate=state.candidate_tensor,
                        candidate_mask=state.candidate_mask_tensor,
                        candidate_pt_indices=state.candidate_pt_indices,
                        graph=state.graph_tensor,
                    )
                rule_action = greedy_select_action(pi)
                state, _, done = val_env.step(rule_action.cpu().numpy())
                if done.all():
                    break
        finally:
            self.ppo.policy.train()

        makespan = float(np.mean(val_env.current_makespan))
        twt = float(np.mean(getattr(
            val_env, 'current_twt', np.zeros(self.validation_set_size))))
        mw = getattr(val_env, 'makespan_weight', 1.0)
        tw = getattr(val_env, 'twt_weight', 1.0)
        return makespan, twt, mw * makespan + tw * twt

    def save_model(self, model_name=None):
        super().save_model(model_name=model_name)
        path_name = model_name if model_name is not None else self.model_name
        path = f"{self.result_dir}/{path_name}.pth"
        if os.path.exists(path):
            obj = torch.load(path, map_location='cpu')
            obj.setdefault('hgt_hyperparams', {})
            obj['hgt_hyperparams'].update({
                'num_rules': len(self.rule_menu),
                'rule_menu': list(self.rule_menu),
                'rule_actor_channels': self.ppo.policy.rule_actor.channel_list,
            })
            torch.save(obj, path)


__all__ = ["PPODispatch", "HGTDispatchTrainer"]
