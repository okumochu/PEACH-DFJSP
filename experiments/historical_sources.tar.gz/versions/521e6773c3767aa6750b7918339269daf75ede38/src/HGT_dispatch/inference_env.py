"""
HGT_dispatch inference iterator.

Thin wrapper around :class:`src.HGT.inference_env.InferenceEnv` that swaps in
:class:`src.HGT_dispatch.hgt_dispatch_env.FJSPEnvHGTDispatch` as the static
env (so its rule-id action space survives across event-bounded segments).

The iteration logic, fixed-ops freezing, dynamic-event handling, and snapshot
collection are all inherited verbatim — they're action-space-agnostic.

Use ``run_with_solver`` exactly as in the parent. ``run`` is overridden to
accept a trained ``HGTDispatch`` policy and produce a greedy rollout per
segment via ``make_dispatch_greedy_solver_fn``.
"""

from __future__ import annotations

from functools import partial
from typing import Any, Dict, Optional, Sequence

import numpy as np
import torch

from src.HGT.inference_env import InferenceEnv
from src.HGT_dispatch.hgt_dispatch_env import FJSPEnvHGTDispatch
from src.utils.rl_utils import greedy_select_action


class InferenceEnvDispatch(InferenceEnv):
    """Inference iterator that uses ``FJSPEnvHGTDispatch`` as the static env.

    ``run`` is replaced by a greedy-rollout entrypoint suited to the
    rule-action policy; ``run_with_solver`` is unchanged.

    ``rule_menu`` must match the menu the policy was trained on (read from
    the checkpoint's ``hgt_hyperparams['rule_menu']``); otherwise rule indices
    don't line up with the agent's logits. Defaults to None, which lets the
    static env fall back to all 11 canonical rules.
    """

    def __init__(self, n_j: int, n_m: int, device,
                 rule_menu: Optional[Sequence[str]] = None):
        factory = partial(FJSPEnvHGTDispatch, rule_menu=rule_menu)
        super().__init__(n_j, n_m, device, env_factory=factory)

    def run(
        self,
        policy,
        dynamic_data: Dict[str, Any],
        *,
        makespan_weight: Optional[float] = None,
        twt_weight: Optional[float] = None,
        verbose: bool = False,
        collect_snapshots: bool = False,
    ) -> Dict[str, Any]:
        """Greedy rollout per segment with the trained HGT_dispatch policy."""
        solver_fn = make_dispatch_greedy_solver_fn(policy, self.device)
        return self.run_with_solver(
            solver_fn, dynamic_data,
            makespan_weight=makespan_weight, twt_weight=twt_weight,
            verbose=verbose, collect_snapshots=collect_snapshots,
        )


def make_dispatch_greedy_solver_fn(policy, device):
    """Build a static-solver callable suitable for ``run_with_solver``.

    The callable plays argmax(rule logits) at every step until the env is
    done, then computes objective metrics — analogous to
    ``src.benchmark.solver_adapter.make_greedy_solver_fn`` but for the
    rule-action HGT_dispatch policy.
    """
    def _solve(env, mw, tw):
        env.makespan_weight = mw
        env.twt_weight = tw
        state = env.state  # set by set_initial_data_with_fixed_schedule
        policy.eval()
        steps = 0
        done = env.done()
        while not done.all():
            with torch.no_grad():
                pi, _ = policy(
                    candidate=state.candidate_tensor,
                    candidate_mask=state.candidate_mask_tensor,
                    candidate_pt_indices=state.candidate_pt_indices,
                    graph=state.graph_tensor,
                )
            rule_action = greedy_select_action(pi).cpu().numpy()
            state, _, done = env.step(rule_action)
            steps += 1
        env._recompute_objectives()
        ms = float(env.current_makespan[0])
        twv = float(env.current_twt[0])
        return {
            'makespan': ms, 'twt': twv, 'objective': mw * ms + tw * twv,
            'step_count': steps, 'best_env': env, 'best_env_idx': 0,
        }
    return _solve


__all__ = ["InferenceEnvDispatch", "make_dispatch_greedy_solver_fn"]
