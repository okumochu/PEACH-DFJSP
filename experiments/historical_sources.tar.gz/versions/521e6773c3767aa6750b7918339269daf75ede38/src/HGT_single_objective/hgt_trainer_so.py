"""Single-objective HGT PPO trainer.

Slimmed copy of ``HGTTrainer``:
- single validation track (static only, no dynamic)
- no curriculum learning
- no TWT / objective-weight plumbing
- reuses ``Memory`` and ``PPO`` from ``src.HGT.hgt_trainer`` (their bodies
  don't touch TWT directly)
- ``PPO.policy_cls`` is swapped to ``HGTSingleObj``
"""

import sys
import time

import numpy as np
import torch
from tqdm import tqdm
import wandb

# Reuse the base PPO + Memory; swap the policy class via a subclass.
from src.HGT.hgt_trainer import Memory, PPO as BasePPO
from src.utils.checkpoint_util import checkpoint_safe_metadata
from src.utils.reproducibility import seed_context, set_global_seed
from src.utils.rl_utils import sample_action, greedy_select_action
from src.data_generator.data_generator_single_obj import (
    create_data_generator_single_obj,
)

from .hgt_env_so import FJSPEnvHGTSingleObj
from .hgt_network_so import HGTSingleObj


class PPOSingleObj(BasePPO):
    """PPO with single-obj policy class. Update body is inherited verbatim;
    the TWT-related kwargs default to None and become harmless zeros in
    the metrics dict."""

    policy_cls = HGTSingleObj


class HGTSingleObjTrainer:
    """Single-objective PPO trainer (makespan-only, no curriculum, no events)."""

    def __init__(self, config):
        self.n_j = config.n_j
        self.n_m = config.n_m
        self.config = config
        self.max_updates = config.max_updates
        self.reset_env_episode = config.reset_env_episode
        self.num_envs = config.num_envs
        self.seed = int(getattr(config, 'seed', 42))
        self.reproducibility = set_global_seed(self.seed)
        config.reproducibility = self.reproducibility

        self.data_generator = create_data_generator_single_obj(config)

        self.use_lowerbound_differencing = True

        self.result_dir = getattr(config, 'result_dir', './result')
        self.data_name = f'{self.n_j}x{self.n_m}'
        self.model_name = getattr(config, 'model_name', self.data_name)

        # Build env first so we can read feature dims off it.
        self.env = self._create_environment()
        config.op_feature_dim = self.env.op_fea_dim
        config.job_feature_dim = self.env.job_fea_dim
        config.machine_feature_dim = self.env.mch_fea_dim
        config.pt_feature_dim = self.env.pt_fea_dim

        self.ppo = PPOSingleObj(config)
        self.memory = Memory(gamma=config.gamma, gae_lambda=config.gae_lambda)

        # Validation
        self.update_per_validate = getattr(config, 'update_per_validate', 200)
        self.validation_seed = getattr(config, 'seed', 42)
        self.validation_set_size = getattr(config, 'validation_set_size', 30)
        self.validation_data = self._generate_validation_set()
        self.best_val_makespan = float('inf')

        # Wandb
        self.wandb_project = getattr(config, 'wandb_project', 'DFJSP_single_obj')
        self.wandb_enabled = getattr(config, 'wandb_enabled', True)

        if self.wandb_enabled:
            run_name = getattr(config, 'wandb_run_name', None) or (
                f"HGT_SO_{self.data_name}_{self.model_name}")
            wandb.init(
                project=self.wandb_project,
                name=run_name,
                config=vars(config),
            )

    def _create_environment(self):
        return FJSPEnvHGTSingleObj(
            self.n_j,
            self.n_m,
            device=self.config.device,
        )

    def _policy_forward(self, policy, state):
        return policy(
            candidate=state.candidate_tensor,
            candidate_mask=state.candidate_mask_tensor,
            candidate_pt_indices=state.candidate_pt_indices,
            graph=state.graph_tensor,
        )

    def sample_training_instances(self):
        return self.data_generator.sample_env(self.num_envs)

    def _generate_validation_set(self):
        with seed_context(self.validation_seed):
            data = self.data_generator.sample_env(self.validation_set_size)
        return data

    def _greedy_rollout(self, val_data):
        """Run a greedy (argmax) rollout. Returns mean makespan over batch."""
        val_env = FJSPEnvHGTSingleObj(
            self.n_j,
            self.n_m,
            device=self.config.device,
        )
        state = val_env.set_initial_data_static(val_data)

        self.ppo.policy.eval()
        try:
            while True:
                with torch.no_grad():
                    pi, _ = self._policy_forward(self.ppo.policy, state)
                action = greedy_select_action(pi)
                state, _reward, done = val_env.step(action.cpu().numpy())
                if done.all():
                    break
        finally:
            self.ppo.policy.train()

        return float(np.mean(val_env.current_makespan))

    def train(self):
        self.train_st = time.time()

        for i_update in tqdm(range(self.max_updates), file=sys.stdout,
                              desc='progress', colour='blue'):
            should_resample = (i_update % self.reset_env_episode == 0)
            if should_resample:
                data = self.sample_training_instances()
                state = self.env.set_initial_data_static(data)
            else:
                state = self.env.reset()

            ep_rewards = -self.env.init_quality.copy()

            while True:
                self.memory.push(state)

                with torch.no_grad():
                    pi_envs, vals_envs = self._policy_forward(
                        self.ppo.policy_old, state)

                action_envs, action_logprob_envs = sample_action(pi_envs)
                state, reward, done = self.env.step(actions=action_envs.cpu().numpy())
                ep_rewards += reward
                reward = torch.from_numpy(reward).to(self.ppo.device)

                self.memory.reward_seq.append(reward)
                self.memory.action_seq.append(action_envs)
                self.memory.log_probs.append(action_logprob_envs)
                self.memory.val_seq.append(vals_envs.squeeze(1))

                if done.all():
                    break

            # PPO update — TWT kwargs default to None so the metrics dict
            # has zeroed raw_twt / raw_objective fields (harmless).
            loss, v_loss, p_loss, update_metrics = self.ppo.update(
                self.memory, update_step=i_update,
                raw_rewards=ep_rewards,
                raw_makespan=self.env.current_makespan,
                makespan_weight=1.0, twt_weight=0.0,
            )
            self.memory.clear_memory()

            metrics_to_log = dict(update_metrics)

            if i_update % self.update_per_validate == 0:
                val_makespan = self._greedy_rollout(self.validation_data)
                tqdm.write(
                    f'[Validation @ {i_update}] makespan={val_makespan:.2f}')
                if val_makespan < self.best_val_makespan:
                    self.best_val_makespan = val_makespan
                    self.save_model(model_name=f"best_{self.model_name}")
                    tqdm.write(f'  -> New best model (makespan: {val_makespan:.2f})')

                if self.wandb_enabled:
                    metrics_to_log.update({
                        'val/makespan': val_makespan,
                        'val/best_makespan': self.best_val_makespan,
                    })

            if self.wandb_enabled and metrics_to_log:
                metrics_to_log['update_step'] = i_update
                wandb.log(metrics_to_log)

        self.train_et = time.time()
        if self.wandb_enabled:
            wandb.log({'train/training_wall_clock_s': self.train_et - self.train_st})

        self.save_model()
        if self.wandb_enabled:
            wandb.finish()

    def save_model(self, model_name=None):
        if model_name is None:
            model_name = self.model_name
        hgt_hyperparams = {
            'n_j': self.config.n_j,
            'n_m': self.config.n_m,
            'op_feature_dim': getattr(self.config, 'op_feature_dim', 9),
            'job_feature_dim': getattr(self.config, 'job_feature_dim', 4),
            'machine_feature_dim': getattr(self.config, 'machine_feature_dim', 6),
            'hidden_dim': getattr(self.config, 'hidden_dim', 128),
            'num_hgt_layers': getattr(self.config, 'num_hgt_layers', 4),
            'num_heads': getattr(self.config, 'num_heads', 1),
            'dropout': getattr(self.config, 'dropout', 0.1),
            'lr': getattr(self.config, 'lr', 3e-5),
            'gamma': getattr(self.config, 'gamma', 1.0),
            'gae_lambda': getattr(self.config, 'gae_lambda', 0.98),
            'eps_clip': getattr(self.config, 'eps_clip', 0.2),
            'k_epochs': getattr(self.config, 'k_epochs', 4),
            'max_grad_norm': getattr(self.config, 'max_grad_norm', 1.0),
            'vloss_coef': getattr(self.config, 'vloss_coef', 0.5),
            'ploss_coef': getattr(self.config, 'ploss_coef', 1.0),
            'objective_weights': {'makespan_weight': 1.0, 'twt_weight': 0.0},
            'seed': self.seed,
            'reproducibility': dict(getattr(
                self.config, 'reproducibility', self.reproducibility)),
            'actor_channels': self.ppo.policy.actor.channel_list,
            'critic_channels': self.ppo.policy.critic.channel_list,
            'single_objective': True,
            'use_pt_nodes': True,
            # Old/static design: no dynamic-event observability columns
            # (mch_fea_dim=6). Mirrors train_graph_rl_static.py. Informational
            # for checkpoint inspection; the network is rebuilt from the saved
            # *_feature_dim values and the SO env hardwires this design.
            'use_dynamic_event_features': False,
            'dp_lb_diff': {
                'enabled': self.use_lowerbound_differencing,
            },
            'lowerbound_features': {
                'enabled': True,
            },
            'generator_type': getattr(self.config, 'generator_type', 'SD1'),
        }
        hgt_hyperparams['pt_feature_dim'] = getattr(
            self.config, 'pt_feature_dim', 2)
        save_obj = {
            'state_dict': self.ppo.policy.state_dict(),
            'hgt_hyperparams': checkpoint_safe_metadata(hgt_hyperparams),
            'config': checkpoint_safe_metadata(self.config),
        }
        torch.save(save_obj, f"{self.result_dir}/{model_name}.pth")
