"""
HGT_dispatch policy network.

Subclasses :class:`src.HGT.hgt_network.HGT` and replaces only the actor head:
instead of producing logits over ``J*M`` (job, machine) pairs, the actor combines
the four per-node-type weighted pools into a global state vector and produces
logits over ``num_rules`` dispatching rules. The chosen rule is then applied
deterministically by ``FJSPEnvHGTDispatch.step`` to pick the actual
(job, machine) pair.

The critic head is reused verbatim from the parent (via the parent's
``_critic_forward`` helper). Feature extractor is also reused — same
embeddings, same HGT layers.

Input/output shapes match the parent so the trainer + memory + log-prob path
work unchanged: ``forward`` returns ``(pi[sz_b, num_rules], v[sz_b, 1])``.
The Categorical distribution induced by ``pi`` is over rule indices.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import MLP

from src.HGT.hgt_network import HGT


class HGTDispatch(HGT):
    """HGT with a rule-logits actor head.

    Args (added on top of parent's config):
        config.num_rules: int — size of the dispatching-rule menu.
        config.rule_actor_channels: optional list of channel sizes for the
            actor MLP. Default: [4*d, 256, 128, 64, num_rules].
    """

    def __init__(self, config):
        super().__init__(config)
        device = torch.device(config.device)

        num_rules = int(getattr(config, 'num_rules', 0))
        if num_rules <= 0:
            raise ValueError(
                "HGTDispatch requires config.num_rules > 0 (size of the "
                "dispatching-rule menu)."
            )
        self.num_rules = num_rules

        d = self.embedding_output_dim
        rule_actor_input_dim = 4 * d  # one pool per node type (op, job, machine, pt)
        default_channels = [rule_actor_input_dim, 256, 128, 64, num_rules]
        rule_actor_channels = (
            getattr(config, 'rule_actor_channels', None) or default_channels
        )
        self.rule_actor = MLP(
            channel_list=rule_actor_channels,
            act=torch.tanh,
            dropout=0.0,
            norm=None,
            bias=True,
        ).to(device)

    def forward(self, candidate, candidate_mask, candidate_pt_indices, graph):
        """
        Returns:
            pi [sz_b, num_rules]: policy over dispatching rules.
            v  [sz_b, 1]:         state value.
        """
        (
            job_node_embedding,
            pt_node_embedding,
            flat_node_embeddings,
            batch_vectors,
        ) = self.feature_extractor(graph)

        # Reuse parent's per-type weighted pools (4 pools).
        actor_weighted_pools = {
            nt: self.actor_node_pools[nt](
                flat_node_embeddings[nt], batch_vectors[nt]
            )
            for nt in self.node_types
        }

        sz_b = candidate.size(0)
        J = candidate.size(1)
        M = candidate_mask.size(2)
        d = self.embedding_output_dim

        global_state = torch.cat(
            [actor_weighted_pools[nt] for nt in self.node_types], dim=-1
        )                                                                   # [sz_b, 4*d]
        rule_logits = self.rule_actor(global_state)                          # [sz_b, num_rules]

        mask = candidate_mask.reshape(sz_b, -1).bool()
        all_masked = mask.all(dim=1)
        if all_masked.any():
            # Terminal envs: uniform logits keep softmax finite; V is irrelevant.
            rule_logits = rule_logits.clone()
            rule_logits[all_masked] = 0.0
        pi = F.softmax(rule_logits, dim=1)

        if job_node_embedding.size(1) < J:
            pad = torch.zeros(
                sz_b, J - job_node_embedding.size(1), d,
                device=job_node_embedding.device,
            )
            job_node_embedding = torch.cat([job_node_embedding, pad], dim=1)

        fea_job_serialized = (
            job_node_embedding.unsqueeze(2).repeat(1, 1, M, 1).reshape(sz_b, M * J, d)
        )

        pt_indices_flat = candidate_pt_indices.reshape(sz_b, J * M)
        pt_indices_safe = pt_indices_flat.clamp(min=0)
        pt_indices_expanded = pt_indices_safe.unsqueeze(-1).expand(-1, -1, d)
        fea_pt_serialized = torch.gather(pt_node_embedding, 1, pt_indices_expanded)
        invalid_mask = (pt_indices_flat < 0).unsqueeze(-1).expand(-1, -1, d)
        fea_pt_serialized = fea_pt_serialized.masked_fill(invalid_mask, 0.0)

        v = self._critic_forward(
            flat_node_embeddings, batch_vectors,
            fea_job_serialized, fea_pt_serialized, mask, all_masked,
        )

        return pi, v


__all__ = ["HGTDispatch"]
