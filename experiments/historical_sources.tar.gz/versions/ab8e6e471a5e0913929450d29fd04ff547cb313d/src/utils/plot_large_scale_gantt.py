#!/usr/bin/env python3
"""
Render Gantt charts from exp_large_scale_dispatching.py output.

The experiment writes raw ``schedules.json`` (per run: the full instance plus
each method's final schedule) but no plots. This script reconstructs the
Gantt for one method (default: the proposed ``rl`` policy) and overlays the
dynamic-event story so the policy's adaptive rescheduling is legible:

  * a DASHED vertical line at every new-job arrival wave,
  * a SOLID vertical line at every priority-change (priority shock),
  * a YELLOW border around the single most-urgent reprioritized job
    (weight=5) at each priority shock — "most urgent" = smallest slack
    (due_date - shock_time) among the jobs that shock reprioritized.

Usage:
    # Point at a scenario dir (auto-finds schedules.json) or the file itself
    python src/utils/plot_large_scale_gantt.py result/exp_large_scale_dispatching/<run>/priority_shock
    python src/utils/plot_large_scale_gantt.py .../priority_shock/schedules.json

    # Specific runs / method / output dir
    python src/utils/plot_large_scale_gantt.py <path> --runs 0 2 --method rl --out_dir /tmp/g
"""
import os
import sys
import json
import argparse
from typing import Dict, Any, List, Optional, Set, Tuple

# src/utils/<this file> -> project root is three levels up.
sys.path.append(os.path.dirname(os.path.dirname(
    os.path.dirname(os.path.abspath(__file__)))))

from src.utils.gantt_util import draw_gantt_chart


def _resolve_schedules_path(path: str) -> str:
    """Accept either a schedules.json file or a dir containing one."""
    if os.path.isfile(path):
        return path
    candidate = os.path.join(path, 'schedules.json')
    if os.path.isfile(candidate):
        return candidate
    raise FileNotFoundError(
        f"No schedules.json found at '{path}' (looked for the file and "
        f"'{candidate}').")


def _arrival_waves(dynamic_events: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Collapse the per-job arrival-time list into one marker per wave."""
    times = [float(t) for t in (dynamic_events.get('new_job_arrival') or [])]
    counts: Dict[float, int] = {}
    for t in times:
        counts[t] = counts.get(t, 0) + 1
    return [
        {'time': t, 'label': f'Arrival: +{n} job{"s" if n != 1 else ""}'}
        for t, n in sorted(counts.items())
    ]


def _priority_markers_and_urgent(
    dynamic_events: Dict[str, Any],
    due_date_by_job: Dict[int, float],
) -> Tuple[List[Dict[str, Any]], Set[int]]:
    """Build priority-shock markers and the set of most-urgent jobs.

    For each priority change, the most-urgent reprioritized job is the one
    with the smallest slack (due_date - shock_time); ties break on the lower
    job index. Returns (markers, highlight_job_ids).
    """
    markers: List[Dict[str, Any]] = []
    highlight: Set[int] = set()
    for i, ev in enumerate(dynamic_events.get('priority_change') or []):
        if not isinstance(ev, dict):
            continue
        t = float(ev.get('time', 0.0))
        job_indices = [int(j) for j in (ev.get('job_indices') or [])]
        new_weight = ev.get('new_weight')
        label = f'Priority shock {i + 1}: {len(job_indices)} jobs'
        if new_weight is not None:
            label += f' → w={int(round(float(new_weight)))}'
        markers.append({'time': t, 'affected_count': len(job_indices),
                        'label': label})

        candidates = [j for j in job_indices if j in due_date_by_job]
        if candidates:
            urgent = min(candidates, key=lambda j: (due_date_by_job[j] - t, j))
            highlight.add(urgent)
    return markers, highlight


def _split_coincident(
    arrivals: List[Dict[str, Any]],
    priorities: List[Dict[str, Any]],
    tol: float = 0.5,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    """Pair arrival + priority events at the same time into one combined marker.

    Returns (combined, lone_arrivals, lone_priorities). In this experiment
    priority changes are retimed to coincide with arrival waves
    (exp_large_scale_dispatching.couple_priority_to_arrivals), so each arrival
    typically pairs with a priority change and is drawn as a single
    'Arrival + Priority' marker instead of an overlapping dashed+solid pair.
    """
    combined: List[Dict[str, Any]] = []
    lone_arrivals: List[Dict[str, Any]] = []
    used: Set[int] = set()
    for a in arrivals:
        at = float(a.get('time', 0.0))
        match = next(
            (j for j, p in enumerate(priorities)
             if j not in used and abs(float(p.get('time', 0.0)) - at) <= tol),
            None)
        if match is None:
            lone_arrivals.append(a)
            continue
        used.add(match)
        affected = priorities[match].get('affected_count')
        label = f'Arrival + Priority ({affected} jobs)' if affected \
            else 'Arrival + Priority'
        combined.append({'time': at, 'label': label})
    lone_priorities = [p for j, p in enumerate(priorities) if j not in used]
    return combined, lone_arrivals, lone_priorities


def plot_record(record: Dict[str, Any], method: str, scenario: str,
                out_dir: str) -> Optional[str]:
    """Render one run's Gantt for ``method``; return the output path or None."""
    run_idx = record.get('run_idx')
    schedules = record.get('schedules') or {}
    sched_rec = schedules.get(method)
    if sched_rec is None:
        print(f"  [run {run_idx}] no '{method}' schedule — "
              f"available: {sorted(schedules)}; skipping")
        return None

    schedule = sched_rec.get('schedule') or []
    if not schedule:
        print(f"  [run {run_idx}] '{method}' schedule is empty; skipping")
        return None

    job_data = sched_rec.get('job_data') or []
    num_machines = int(sched_rec.get('num_machines') or 0)
    num_jobs = int(sched_rec.get('num_jobs') or len(job_data))
    due_date_by_job = {
        int(jd['job_idx']): float(jd.get('due_date', float('inf')))
        for jd in job_data
    }

    dynamic_events = (record.get('instance_data') or {}).get(
        'dynamic_events') or {}
    arrivals = _arrival_waves(dynamic_events)
    priority_markers, highlight_job_ids = _priority_markers_and_urgent(
        dynamic_events, due_date_by_job)
    # Arrivals and priority shocks fire together in this experiment, so merge
    # same-time pairs into one combined marker; lone events keep dashed/solid.
    combined_events, lone_arrivals, lone_priorities = _split_coincident(
        arrivals, priority_markers)
    # Breakdowns: pass the raw per-machine list (draw_gantt_chart groups by
    # time into one dash-dot marker per wave). Repair periods + interrupted
    # ops come from the solved schedule record.
    breakdowns = dynamic_events.get('machine_breakdown') or []
    breakdown_periods = sched_rec.get('breakdown_periods') or []
    interrupted_ops = sched_rec.get('interrupted_ops') or []

    events_for_plot = {
        'new_job_arrival': lone_arrivals,
        'priority_change': lone_priorities,
        'combined_event': combined_events,
        'machine_breakdown': breakdowns,
    }

    makespan = sched_rec.get('makespan')
    twt = sched_rec.get('twt')
    objective = sched_rec.get('objective')
    title = (
        f'{scenario} — {method.upper()}  (run {run_idx})   '
        f'makespan={makespan:.1f}, TWT={twt:.1f}, obj={objective:.1f}'
        if makespan is not None else f'{scenario} — {method} (run {run_idx})'
    )

    os.makedirs(out_dir, exist_ok=True)
    output_path = os.path.join(out_dir, f'{method}_run{run_idx}.png')
    draw_gantt_chart(
        schedule=schedule,
        num_machines=num_machines,
        num_jobs=num_jobs,
        output_path=output_path,
        title=title,
        job_data=job_data,
        dynamic_events=events_for_plot,
        breakdown_periods=breakdown_periods,
        interrupted_ops=interrupted_ops,
        highlight_job_ids=highlight_job_ids,
    )
    n_bd_waves = len({float(b['time']) for b in breakdowns
                      if isinstance(b, dict)})
    print(f"  [run {run_idx}] {method}: {len(schedule)} ops, "
          f"{len(combined_events)} arrival+priority, "
          f"{len(lone_arrivals)} lone-arrival, {len(lone_priorities)} "
          f"lone-priority, {n_bd_waves} breakdown wave(s), "
          f"urgent jobs={sorted(highlight_job_ids)} -> {output_path}")
    return output_path


def main():
    ap = argparse.ArgumentParser(
        description='Gantt charts from exp_large_scale_dispatching schedules.json')
    ap.add_argument('path', type=str,
                    help='Path to schedules.json or the scenario dir holding it.')
    ap.add_argument('--method', type=str, default='rl',
                    help="Method key to render (default: 'rl').")
    ap.add_argument('--runs', type=int, nargs='+', default=None,
                    help='Run indices to render (default: all in the file).')
    ap.add_argument('--out_dir', type=str, default=None,
                    help='Output dir (default: <scenario_dir>/gantt).')
    args = ap.parse_args()

    sched_path = _resolve_schedules_path(args.path)
    scenario_dir = os.path.dirname(os.path.abspath(sched_path))
    scenario = os.path.basename(scenario_dir) or 'schedule'
    out_dir = args.out_dir or os.path.join(scenario_dir, 'gantt')

    with open(sched_path, 'r', encoding='utf-8') as f:
        payload = json.load(f)
    records = payload.get('records') or []
    if not records:
        print(f"No records in {sched_path}")
        return

    by_idx = {int(r.get('run_idx')): r for r in records
              if r.get('run_idx') is not None}
    selected = (args.runs if args.runs is not None
                else sorted(by_idx.keys()))

    print(f"Rendering '{args.method}' Gantts for {scenario} "
          f"(runs {selected}) from {sched_path}")
    written = []
    for run_idx in selected:
        rec = by_idx.get(run_idx)
        if rec is None:
            print(f"  [run {run_idx}] not in file; skipping")
            continue
        out = plot_record(rec, args.method, scenario, out_dir)
        if out:
            written.append(out)
    print(f"\nWrote {len(written)} Gantt chart(s) to {out_dir}")


if __name__ == '__main__':
    main()
