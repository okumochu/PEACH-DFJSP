"""Run one deterministic greedy policy inference on a generated instance."""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch

from src.HGT.inference_env import InferenceEnv
from src.data_generator import DataGenerator
from src.utils.config_util import create_inference_config, parse_size
from src.utils.model_utils import load_model
from src.utils.reproducibility import seed_context, set_global_seed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True, help="Packaged .pth checkpoint")
    parser.add_argument("--size", default="20x10", help="Generated shop size, NjxNm")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()

    set_global_seed(args.seed)
    n_j, n_m = parse_size(args.size)
    device = args.device
    if str(device).startswith("cuda") and not torch.cuda.is_available():
        device = "cpu"
    policy, hparams, weights = load_model(args.model, device)
    config = create_inference_config(
        n_j=n_j, n_m=n_m, device=device, seed=args.seed,
        num_new_job_arrivals=0, num_machine_breakdowns=0,
        num_priority_changes=0)
    with seed_context(args.seed):
        instance = DataGenerator(config).sample_env(num_envs=1)
    runner = InferenceEnv(
        n_j, n_m, device,
        use_pt_nodes=bool(hparams.get("use_pt_nodes", True)),
        use_dynamic_event_features=bool(
            hparams.get("use_dynamic_event_features", True)))
    result = runner.run(
        policy, instance,
        makespan_weight=weights["makespan_weight"],
        twt_weight=weights["twt_weight"])
    print(f"objective={result['objective']:.6f}")
    print(f"makespan={result['makespan']:.6f}")
    print(f"twt={result['twt']:.6f}")


if __name__ == "__main__":
    main()
