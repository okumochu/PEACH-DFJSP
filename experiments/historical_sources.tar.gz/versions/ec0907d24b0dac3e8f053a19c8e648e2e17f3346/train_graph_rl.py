#!/usr/bin/env python3
"""
HGT Training Entry Point

This script provides the main entry point for training the HGT-based model
for Flexible Job Shop Scheduling Problems, mirroring the DANIEL entry point.

Usage:
    python train_graph_rl.py
"""

import os
import sys
import argparse
from typing import Optional

# Add the project root to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.utils.config_util import create_hgt_config
from src.HGT.hgt_trainer import HGTTrainer


def main(config_path: Optional[str] = None,
         output_dir: str = './results',
         experiment_name: str = 'exp_hgt',
         wandb_run_name: Optional[str] = None,
         **config_overrides):
    """
    Main function for HGT training.

    Args:
        config_path: (unused for HGT) path to a configuration file
        output_dir: Output directory for results
        **config_overrides: Additional configuration parameters
    """

    # Build configuration using centralized config system
    overrides = dict(config_overrides)
    overrides['use_pt_nodes'] = True
    if wandb_run_name is not None:
        overrides['wandb_run_name'] = wandb_run_name
    config = create_hgt_config(experiment_name, create_result_dir=True, **overrides)

    trainer = HGTTrainer(config)
    trainer.train()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='HGT Training for FJSP')
    parser.add_argument('--output_dir', type=str, default='./results', help='Directory to save outputs')
    parser.add_argument('--experiment_name', type=str, default='exp_hgt', help='Experiment name for results/wandb')
    parser.add_argument('--wandb_run_name', type=str, default=None, help='Run name for wandb')
    parser.add_argument('--wandb_project', type=str, default=None,
                        help='W&B project name')
    parser.add_argument('--size', type=str, default=None,
                        help='Training size as JOBSxMACHINES, e.g. 50x10')
    parser.add_argument('--n_j', type=int, default=None,
                        help='Number of jobs for training')
    parser.add_argument('--n_m', type=int, default=None,
                        help='Number of machines for training')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--device', type=str, default=None)
    parser.add_argument('--max_updates', type=int, default=None)
    parser.add_argument('--num_envs', type=int, default=None)
    parser.add_argument('--micro_batch_size', type=int, default=None,
                        help='Gradient-accumulation chunk size. The effective '
                             '(statistical) batch stays at config.minibatch_size; '
                             'this only caps how many graphs are held in VRAM per '
                             'forward/backward. Needed for large sizes, where a '
                             'full minibatch of graphs does not fit. Omit for no '
                             'accumulation.')
    parser.add_argument('--lr', type=float, default=None,
                        help='Adam learning rate; defaults to config.py '
                             "method_params.training['lr']. Exposed for "
                             'large-size fine-tuning, where the same lr that is '
                             'stable at 20x10 need not be.')
    parser.add_argument('--k_epochs', type=int, default=None,
                        help='PPO epochs per update; defaults to config.py '
                             "method_params.training['k_epochs'] (4). Halving "
                             'it halves both the policy displacement per update '
                             'and the cost of an update, which is the cheapest '
                             'brake when gradient_norm climbs monotonically at '
                             'a large size.')
    parser.add_argument('--minibatch_size', type=int, default=None,
                        help='PPO effective (statistical) minibatch; defaults '
                             "to config.py method_params.training"
                             "['minibatch_size']. This is NOT a memory knob — "
                             'use --micro_batch_size for VRAM. It matters '
                             'because the transition count per update grows '
                             'with problem size while minibatch_size is fixed, '
                             'so one update takes ~36 optimizer steps at 20x10 '
                             'but ~220 at 100x20 with num_envs=20 — all against '
                             'a single policy_old, which is far outside the '
                             'range where PPO\'s clipped objective still '
                             'constrains the update. Raise it (or lower '
                             '--num_envs) to keep steps-per-update in the range '
                             'the recipe was tuned at.')
    parser.add_argument('--init_from', type=str, default=None,
                        help='Warm start from another run\'s checkpoint: loads '
                             'ONLY policy weights, with a fresh optimizer, fresh '
                             'result dir and the update counter at 0. Use for '
                             'cross-size fine-tuning; use --resume to continue '
                             'an interrupted run instead.')
    parser.add_argument('--critic_warmup', type=int, default=0,
                        help='Train ONLY the critic for this many updates '
                             'before normal PPO begins. The actor and the '
                             'shared encoder are frozen, so the policy is '
                             'unchanged during warm-up; it exists to let a '
                             'critic inherited from a smaller size recalibrate '
                             'to the new return scale. Budget it ON TOP of the '
                             'intended actor budget (max_updates = warmup + N).')
    parser.add_argument('--auto_ladder', type=str, default=None,
                        help="Generate the scale ladder from its endpoints "
                             "and one growth factor: 'START:TARGET[:rho]', "
                             "e.g. '10x5:100x20:2'. rho is the per-stage "
                             "growth in problem AREA. Mutually exclusive "
                             "with --scale_curriculum.")
    parser.add_argument('--use_popart', action='store_true',
                        help='Adaptive value-target normalization (PopArt) '
                             'with an output-preserving rescale of the critic '
                             'head. Replaces --normalize_returns.')
    parser.add_argument('--popart_beta', type=float, default=0.1,
                        help='EMA rate for the PopArt statistics.')
    parser.add_argument('--stage_ev_threshold', type=float, default=None,
                        help='Advance the scale curriculum on critic '
                             'explained variance instead of the value-loss '
                             'plateau. Dimensionless, so it does not depend '
                             'on the return normalizer. Required with '
                             '--use_popart.')
    parser.add_argument('--normalize_returns', action='store_true',
                        help='Divide step rewards by '
                             '(n_j*n_m)/ref_area so critic targets '
                             'sit at typical-20x10 scale at EVERY problem '
                             'size. Actor updates are unchanged (advantages '
                             'are z-scored per env, so a per-env constant '
                             'divides out); this only conditions the critic, '
                             'whose outsized gradients through the shared '
                             'encoder are what broke large-size fine-tuning.')
    parser.add_argument('--return_norm_ref_area', type=float, default=200.0,
                        help='Reference problem area (n_j*n_m of the recipe '
                             'size; 20x10 = 200) for --normalize_returns.')
    parser.add_argument('--scale_curriculum', type=str, default=None,
                        help='Comma-separated size ladder, smallest first, each '
                             'NjxNm[:micro], e.g. "20x10:128,30x10:128,50x10:128". '
                             'Training starts at the first size and steps up '
                             'when the value loss at the current size has '
                             'converged (plateau + stability gate); validation '
                             'and checkpoints are pinned to the FINAL size. '
                             'Omit --size/--n_j (the ladder defines them) and '
                             'pass --disable_curriculum (the DDT pacer cannot '
                             'span stage rebuilds).')
    parser.add_argument('--stage_min_updates', type=int, default=20,
                        help='Minimum updates per stage before advancing.')
    parser.add_argument('--stage_max_updates', type=int, default=80,
                        help='Updates after which an unconverged non-final '
                             'stage stops the run (STUCK) instead of stepping '
                             'up on a bad critic.')
    parser.add_argument('--stage_window', type=int, default=10,
                        help='Window length for the plateau/stability test.')
    parser.add_argument('--stage_plateau_tol', type=float, default=0.5,
                        help='Max relative change between consecutive '
                             'value-loss window MEDIANS to call it a '
                             'plateau (median-based: single spikes do '
                             'not move it).')
    parser.add_argument('--stage_cv_tol', type=float, default=0.8,
                        help='Max robust spread (MAD/median) of the last '
                             'window. Median-based so intermittent spikes '
                             'on a flat baseline pass, erratic level '
                             'jumps do not.')
    parser.add_argument('--stage_div_factor', type=float, default=5.0,
                        help='value_loss above div_factor x stage reference '
                             'counts toward divergence.')
    parser.add_argument('--stage_div_patience', type=int, default=10,
                        help='Consecutive above-bar updates before aborting.')
    parser.add_argument('--stage_settle_updates', type=int, default=None,
                        help='Grace period after each stage switch before the '
                             'collapse test arms and before a stop may be '
                             'called a success. A rail, not a tuning knob: '
                             'defaults to --stage_window, which is the number '
                             'of updates PopArt needs to re-adapt at the '
                             'default beta.')
    parser.add_argument('--stage_descend_patience', type=int, default=None,
                        help='Minimum updates at a stage before a slow decline '
                             'may demote it. Defaults to max(2*window, '
                             'min_stage_updates).')
    parser.add_argument('--stage_final_hold', type=int, default=None,
                        help='Stop the run (successfully) after this many '
                             'updates on the FINAL ladder stage, instead of '
                             'training until --max_updates. Pins the wall '
                             'clock spent at the most expensive size: update '
                             'cost grows ~quadratically with problem area, '
                             'so leftover global budget landing on the final '
                             'stage swings the runtime by days. Give '
                             '--max_updates slack so it never binds first; '
                             'resume with a larger value to extend the hold.')
    parser.add_argument('--update_per_validate', type=int, default=None,
                        help='Updates between validation runs (defaults to '
                             'config.validation.update_per_validate). Lower it '
                             'for short fine-tune runs, otherwise best-model '
                             'selection has almost no points to choose from.')
    parser.add_argument('--checkpoint_every', type=int, default=None,
                        help='Updates between resumable full-state snapshots '
                             '(defaults to config.training.checkpoint_every).')
    parser.add_argument('--resume', type=str, default=None,
                        help='Path to a resume_state.pth to continue from. Reuses '
                             'that snapshot\'s result dir, rejoins its W&B run, '
                             'and trains from the saved update step.')
    parser.add_argument('--disable_dp_lb_diff', action='store_true',
                        help='Use objective differencing instead of DP-LB-Diff reward')
    parser.add_argument('--reward_measure', choices=['dp', 'chain'], default=None,
                        help="Which admissible bound the reward differences: "
                             "'dp' consults machine free times (default), "
                             "'chain' is the job-chain bound prior lower-bound "
                             "rewards use. Ignored with --disable_dp_lb_diff. "
                             "Features are identical either way, so this "
                             "changes the reward and nothing else.")
    parser.add_argument('--disable_curriculum', action='store_true',
                        help='Disable curriculum learning')
    parser.add_argument('--scale_event_magnitudes_to_size', action='store_true',
                        help='Scale dynamic-event wave AMOUNTS (machines per '
                             'breakdown, jobs per arrival) with the problem '
                             'size, so a shock is the same fraction of the '
                             'shop at every scale. Event TIMING (mtbf, '
                             'lambda, repair duration) is left absolute. '
                             'Required for the scale-generalization study, '
                             'where the config defaults would otherwise mean '
                             'a 60-100%% shutdown at 10x5 and 15-25%% at '
                             '100x20. Off by default: it changes the instance '
                             'distribution at every size but 20x10.')
    parser.add_argument('--disable_wandb', action='store_true',
                        help='Disable wandb logging for this run')
    args = parser.parse_args()
    if args.size is not None and (args.n_j is not None or args.n_m is not None):
        parser.error('Use either --size or --n_j/--n_m, not both.')
    if (args.n_j is None) != (args.n_m is None):
        parser.error('--n_j and --n_m must be provided together.')
    if args.resume is not None and args.init_from is not None:
        parser.error('Use either --resume (continue a run) or --init_from '
                     '(warm start a new run), not both.')
    if getattr(args, 'auto_ladder', None):
        if args.scale_curriculum is not None:
            parser.error('--auto_ladder and --scale_curriculum both define '
                         'the ladder; pass exactly one.')
        from src.utils.scale_curriculum import parse_auto_ladder_spec
        try:
            # The run's --micro_batch_size is stamped on EVERY stage. Peak
            # VRAM is set by the largest stage, so one chunk size sized for
            # the top of the ladder is safe everywhere below it; the reverse
            # (leaving it unset and inheriting the config default) is how an
            # arm reaches 100x20 after weeks and only then runs out of memory.
            _auto = parse_auto_ladder_spec(
                args.auto_ladder, micro=args.micro_batch_size)
        except ValueError as exc:
            parser.error(str(exc))
        # Expand into the existing --scale_curriculum format so every guard
        # and override below applies unchanged.
        args.scale_curriculum = ','.join(
            f'{j}x{m}' if mi is None else f'{j}x{m}:{mi}'
            for j, m, mi in _auto)
        print(f'[auto-ladder] {args.auto_ladder} -> {args.scale_curriculum}')

    if args.scale_curriculum is not None:
        if args.size is not None or args.n_j is not None:
            parser.error('--scale_curriculum defines the sizes itself; '
                         'drop --size/--n_j/--n_m.')
        if not args.disable_curriculum:
            parser.error('--scale_curriculum requires --disable_curriculum '
                         '(the DDT pacer is keyed to the global update index '
                         'and cannot span stage rebuilds).')
        if not (args.normalize_returns or args.use_popart):
            # The ladder needs SOME cross-size return normalization: without
            # one the critic faces the return-scale jump the ladder exists to
            # remove. PopArt is the current answer; --normalize_returns is the
            # older structural one, kept so earlier runs reproduce.
            parser.error(
                '--scale_curriculum requires --use_popart (recommended) or '
                '--normalize_returns. Running the ladder on raw returns '
                'leaves the critic facing the return-scale jump the ladder '
                'exists to remove. For the curriculum ablation, turn the '
                'ladder off and train directly at the target size instead.')
        if not args.scale_event_magnitudes_to_size:
            # Its own help text says "Required on any size-varying run", but
            # nothing enforced it. Without it the config's absolute event
            # amounts mean a 60-100%% capacity loss at 10x5 against 15-25%% at
            # 100x20, so every stage of the ladder would train on a different
            # problem while feeding one table.
            parser.error(
                '--scale_curriculum requires --scale_event_magnitudes_to_size: '
                'the absolute event amounts in config.py are tuned at 20x10 '
                'and mean a near-total shutdown at the bottom of a ladder.')
        if args.use_popart and args.stage_ev_threshold is None:
            # Under PopArt the value loss is a normalized MSE whose units move
            # with sigma for ~1/beta updates after each size change, so the
            # plateau gate can mistake a purely dimensional decay for
            # convergence. The EV gate is dimensionless and immune.
            parser.error(
                '--scale_curriculum with --use_popart requires '
                '--stage_ev_threshold (measured: 0.6): the value-loss plateau gate '
                'is not meaningful when PopArt is rescaling the value target.')

    overrides = {'seed': args.seed}
    if args.scale_curriculum is not None:
        from src.utils.scale_curriculum import parse_stage_list
        try:
            stages = parse_stage_list(args.scale_curriculum)
        except ValueError as exc:
            parser.error(str(exc))
        # The run is sized/named/validated at the FINAL stage; the trainer
        # rebuilds env + generator down to stage 0 before the first update.
        overrides['n_j'], overrides['n_m'] = stages[-1][0], stages[-1][1]
        overrides['scale_curriculum'] = {
            'enabled': True,
            'stages': stages,
            'min_stage_updates': args.stage_min_updates,
            'max_stage_updates': args.stage_max_updates,
            'window': args.stage_window,
            'plateau_tol': args.stage_plateau_tol,
            'cv_tol': args.stage_cv_tol,
            'div_factor': args.stage_div_factor,
            'div_patience': args.stage_div_patience,
            'final_hold_updates': args.stage_final_hold,
            # Was parsed and thrown away while the guard above FORCED the
            # user to supply it, so the ladder advanced on the plateau
            # gate while the operator believed the EV gate was on.
            'ev_threshold': args.stage_ev_threshold,
            # Read by the controller since the bidirectional redesign; without
            # these two lines they were reachable only by editing code, which
            # is the exact shape of the parse-it-then-drop-it defect from an
            # earlier round.
            'settle_updates': args.stage_settle_updates,
            'descend_patience': args.stage_descend_patience,
        }
    if args.size is not None:
        overrides['size'] = args.size
    if args.n_j is not None:
        overrides['n_j'] = args.n_j
        overrides['n_m'] = args.n_m
    if args.device is not None:
        overrides['device'] = args.device
    if args.max_updates is not None:
        overrides['max_updates'] = args.max_updates
    if args.num_envs is not None:
        overrides['num_envs'] = args.num_envs
    if args.micro_batch_size is not None:
        overrides['micro_batch_size'] = args.micro_batch_size
    if args.lr is not None:
        overrides['lr'] = args.lr
    if args.minibatch_size is not None:
        overrides['minibatch_size'] = args.minibatch_size
    if args.k_epochs is not None:
        overrides['k_epochs'] = args.k_epochs
    if args.init_from is not None:
        if not os.path.exists(args.init_from):
            parser.error(f'--init_from path does not exist: {args.init_from}')
        overrides['init_from'] = os.path.abspath(args.init_from)
    if args.critic_warmup:
        overrides['critic_warmup'] = args.critic_warmup
    if args.normalize_returns:
        overrides['normalize_returns'] = True
        overrides['return_norm_ref_area'] = args.return_norm_ref_area
    if args.update_per_validate is not None:
        overrides['update_per_validate'] = args.update_per_validate
    if args.checkpoint_every is not None:
        overrides['checkpoint_every'] = args.checkpoint_every
    if args.disable_dp_lb_diff:
        if args.reward_measure is not None:
            raise SystemExit(
                '--reward_measure selects WHICH bound to difference and is '
                'meaningless with --disable_dp_lb_diff, which differences the '
                'partial objective instead. Pass one or the other.')
        overrides['dp_lb_diff'] = {'enabled': False}
    elif args.reward_measure is not None:
        overrides['dp_lb_diff'] = {'enabled': True,
                                   'measure': args.reward_measure}
    if args.use_popart:
        overrides['use_popart'] = True
        overrides['popart_beta'] = args.popart_beta
    if args.disable_curriculum:
        overrides['disable_curriculum'] = True
    if args.scale_event_magnitudes_to_size:
        overrides['scale_event_magnitudes_to_size'] = True
    if args.disable_wandb:
        overrides['wandb_enabled'] = False
    if args.wandb_project is not None:
        overrides['wandb_project'] = args.wandb_project
    if args.resume is not None:
        if not os.path.exists(args.resume):
            parser.error(f'--resume path does not exist: {args.resume}')
        overrides['resume_path'] = os.path.abspath(args.resume)
        overrides['result_dir'] = os.path.dirname(os.path.abspath(args.resume))
    main(
        output_dir=args.output_dir,
        experiment_name=args.experiment_name,
        wandb_run_name=args.wandb_run_name,
        **overrides,
    )
