#!/usr/bin/env python3
"""Single-objective HGT training entry point.

Trains a makespan-only HGT model on DANIEL SD1 or SD2 random instances at a
fixed (n_j, n_m). Used to replicate Wang et al. (2024) head-to-head against
their published Table I/II/III numbers.

Usage:
    python train_single_obj.py --size 10x5 --data_generator SD1
    python train_single_obj.py --size 15x10 --data_generator SD2
    python train_single_obj.py --size 20x10 --data_generator SD1 --device cuda:1
"""

import argparse
import os
import sys
from typing import Optional

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.utils.config_util import create_hgt_single_obj_config, parse_size
from src.HGT_single_objective.hgt_trainer_so import HGTSingleObjTrainer


def main(size: str,
         data_generator: str = 'SD1',
         experiment_name: Optional[str] = None,
         wandb_run_name: Optional[str] = None,
         **config_overrides):
    n_j, n_m = parse_size(size)
    gen = data_generator.upper()
    exp_name = experiment_name or f"exp_so_{gen}_{n_j}x{n_m}"

    overrides = dict(config_overrides)
    if wandb_run_name is not None:
        overrides['wandb_run_name'] = wandb_run_name
    else:
        overrides['wandb_run_name'] = f'HGT_SO_{gen}_{n_j}x{n_m}'

    config = create_hgt_single_obj_config(
        experiment_name=exp_name, n_j=n_j, n_m=n_m,
        generator_type=gen, **overrides)
    print(f"[train_single_obj] training {gen} {n_j}x{n_m} -> {config.result_dir}")

    trainer = HGTSingleObjTrainer(config)
    trainer.train()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Single-objective HGT training')
    parser.add_argument('--size', type=str, required=True,
                        help='Problem size (e.g. 10x5, 15x10, 20x10)')
    parser.add_argument('--data_generator', type=str, default='SD1',
                        choices=['SD1', 'SD2', 'sd1', 'sd2'],
                        help='DANIEL distribution to sample (default: SD1)')
    parser.add_argument('--experiment_name', type=str, default=None,
                        help='Experiment name (default: exp_so_<GEN>_<size>)')
    parser.add_argument('--wandb_run_name', type=str, default=None,
                        help='Wandb run name override')
    parser.add_argument('--wandb_project', type=str, default=None,
                        help='Wandb project override')
    parser.add_argument('--device', type=str, default=None,
                        help='Device override, e.g. cuda:1 or cpu')
    parser.add_argument('--max_updates', type=int, default=None,
                        help='Override max_updates for quick smoke runs')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--disable_wandb', action='store_true',
                        help='Disable wandb logging for this run')
    args, _unknown = parser.parse_known_args()

    overrides = {}
    if args.device is not None:
        overrides['device'] = args.device
    if args.max_updates is not None:
        overrides['max_updates'] = args.max_updates
    if args.wandb_project is not None:
        overrides['wandb_project'] = args.wandb_project
    overrides['seed'] = args.seed
    if args.disable_wandb:
        overrides['wandb_enabled'] = False

    main(
        size=args.size,
        data_generator=args.data_generator,
        experiment_name=args.experiment_name,
        wandb_run_name=args.wandb_run_name,
        **overrides,
    )
